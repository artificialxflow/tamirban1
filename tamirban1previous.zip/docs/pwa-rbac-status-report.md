# گزارش وضعیت PWA و سطح دسترسی‌ها (RBAC) — به‌روزرسانی

## 📱 وضعیت PWA (Progressive Web App)

### ✅ کارهای انجام شده
- [x] متغیرهای محیطی PWA در `.env.example` تعریف شده
  - `NEXT_PUBLIC_PWA_NAME=TamirBan`
  - `NEXT_PUBLIC_PWA_SHORT_NAME=TamirBan`
  - `NEXT_PUBLIC_PWA_DESCRIPTION=TamirBan CRM Progressive Web App`
- [x] در `explaination.md` ذکر شده که باید PWA باشد (خط 7 و 11)
- [x] معماری Next.js آماده برای PWA است
- [x] در `todo.md` فاز 9 برای PWA تعریف شده (اولویت بالا — 2-3 روز)

### ❌ کارهای باقی‌مانده (اولویت بالا)
- [ ] ایجاد فایل `public/manifest.json` با تنظیمات PWA
  - [ ] نام اپلیکیشن
  - [ ] آیکون‌ها (مختلف سایزها: 192x192, 512x512)
  - [ ] رنگ تم
  - [ ] حالت نمایش (standalone, fullscreen)
  - [ ] شروع URL (`/dashboard`)
- [ ] ایجاد Service Worker (`public/sw.js` یا `public/service-worker.js`)
  - [ ] Cache کردن فایل‌های استاتیک (CSS, JS, Images)
  - [ ] Cache کردن API responses (اختیاری)
  - [ ] Offline support (صفحه Offline)
  - [ ] Background sync (اختیاری)
  - [ ] Push notifications (اختیاری)
- [ ] ثبت Service Worker در `app/layout.tsx`
- [ ] اتصال manifest.json به `app/layout.tsx`
- [ ] ایجاد آیکون‌های PWA در سایزهای مختلف (192x192, 512x512)
- [ ] تست نصب PWA روی موبایل (Android Chrome, iOS Safari)
- [ ] تست Offline mode
- [ ] تست به‌روزرسانی خودکار

### 📅 زمان‌بندی پیشنهادی
**فاز PWA: 2-3 روز**
- روز 1: ایجاد manifest.json و آیکون‌ها
- روز 2: پیاده‌سازی Service Worker
- روز 3: تست و بهینه‌سازی

### 💡 مزایای PWA برای این پروژه
1. **یک کد برای وب و موبایل**: نیازی به اپلیکیشن جداگانه نیست
2. **نصب سریع**: کاربران می‌توانند از مرورگر نصب کنند
3. **به‌روزرسانی خودکار**: تغییرات به صورت خودکار اعمال می‌شود
4. **Offline Support**: امکان استفاده بدون اینترنت
5. **بعداً می‌توان به Native App تبدیل کرد**: با استفاده از Capacitor یا TWA

---

## 🔐 وضعیت RBAC (Role-Based Access Control)

### ✅ کارهای انجام شده (Backend — 80% تکمیل)
- [x] تعریف نقش‌ها در `lib/types/domain.ts`:
  - `SUPER_ADMIN` — مدیر کل
  - `FINANCE_MANAGER` — مدیر مالی
  - `MARKETER` — بازاریاب
  - `CUSTOMER` — مشتری
- [x] تعریف Permissions برای هر نقش در `lib/middleware/rbac.ts`:
  - **SUPER_ADMIN**: دسترسی کامل (users, customers, visits, invoices, marketers, reports, settings)
  - **FINANCE_MANAGER**: فقط خواندن مشتریان، خواندن/نوشتن پیش‌فاکتورها، خواندن گزارش‌ها
  - **MARKETER**: خواندن/نوشتن مشتریان، خواندن/نوشتن ویزیت‌ها، خواندن/نوشتن پیش‌فاکتورها
  - **CUSTOMER**: فقط خواندن اطلاعات خود (مشتریان، پیش‌فاکتورها)
- [x] Middleware `requireRole()` برای بررسی نقش
- [x] Middleware `requirePermission()` برای بررسی permission
- [x] تابع `checkPermission()` برای بررسی دسترسی
- [x] استفاده از RBAC در برخی API Routes (احراز هویت)

### ⚠️ کارهای ناقص (اولویت بالا)

#### 1. محدودسازی دسترسی ادمین اصلی (0% تکمیل)
- [ ] جلوگیری از تغییر نقش خود ادمین اصلی
- [ ] جلوگیری از غیرفعال کردن حساب خود ادمین اصلی
- [ ] افزودن بررسی در `updateMarketer` برای جلوگیری از تغییر نقش ادمین اصلی
- [ ] افزودن بررسی در `updateMarketer` برای جلوگیری از غیرفعال کردن ادمین اصلی
- [ ] نمایش پیام مناسب به کاربر در صورت تلاش برای تغییر غیرمجاز

#### 2. اعمال RBAC در Frontend (UI) — 0% تکمیل
- [ ] ایجاد Hook `usePermissions()` در `lib/hooks/use-permissions.ts`
- [ ] ایجاد کامپوننت `ProtectedComponent` در `components/common/protected-component.tsx`
- [ ] مخفی کردن دکمه‌ها بر اساس نقش:
  - [ ] دکمه "افزودن مشتری" فقط برای MARKETER و SUPER_ADMIN
  - [ ] دکمه "افزودن بازاریاب" فقط برای SUPER_ADMIN
  - [ ] تب "تنظیمات" فقط برای SUPER_ADMIN
  - [ ] دکمه "حذف" فقط برای SUPER_ADMIN
  - [ ] دکمه "ویرایش پیش‌فاکتور" فقط برای FINANCE_MANAGER و SUPER_ADMIN
- [ ] مخفی کردن منوی Sidebar بر اساس نقش
- [ ] نمایش پیام "دسترسی ندارید" در صورت تلاش برای دسترسی غیرمجاز

#### 3. اعمال RBAC در API Routes (تکمیل) — 30% تکمیل
- [ ] بررسی تمام API Routes و افزودن `requireRole()` یا `requirePermission()`
- [ ] محافظت از `/api/customers` با `requirePermission("customers:write")`
- [ ] محافظت از `/api/marketers` با `requireRole("SUPER_ADMIN")`
- [ ] محافظت از `/api/invoices` با `requirePermission("invoices:write")`
- [ ] محافظت از `/api/visits` با `requirePermission("visits:write")`
- [ ] محافظت از `/api/settings` با `requireRole("SUPER_ADMIN")`
- [ ] محافظت از `/api/reports` با `requirePermission("reports:read")`

#### 4. صفحه مدیریت نقش‌ها — 0% تکمیل
- [ ] ایجاد صفحه `/dashboard/settings/roles` برای مدیریت نقش‌ها
- [ ] نمایش لیست نقش‌ها و permissions
- [ ] امکان ایجاد نقش جدید (فقط SUPER_ADMIN)
- [ ] امکان ویرایش permissions نقش‌ها (فقط SUPER_ADMIN)
- [ ] نمایش کاربران هر نقش

### 📅 زمان‌بندی پیشنهادی
**فاز RBAC تکمیل: 3-4 روز**
- روز 1: محدودسازی دسترسی ادمین اصلی + اعمال RBAC در API Routes
- روز 2: ایجاد Hook و کامپوننت‌های Frontend برای RBAC
- روز 3: مخفی کردن UI بر اساس نقش
- روز 4: صفحه مدیریت نقش‌ها + تست

---

## 📊 خلاصه وضعیت

| مورد | وضعیت | درصد تکمیل | اولویت | فاز در todo.md |
|------|-------|------------|--------|----------------|
| **PWA** | ❌ پیاده‌سازی نشده | 10% | بالا | فاز 9 (2-3 روز) |
| **RBAC Backend** | ✅ پیاده‌سازی شده | 80% | بالا | فاز 10 (3-4 روز) |
| **RBAC Frontend** | ❌ پیاده‌سازی نشده | 0% | بالا | فاز 10 (3-4 روز) |
| **محدودسازی ادمین** | ❌ پیاده‌سازی نشده | 0% | بالا | فاز 10 (3-4 روز) |

---

## 🎯 توصیه مسیر پیشرو

### مرحله 1: تکمیل RBAC (اولویت فوری) — 3-4 روز
**چرا اول؟** امنیت سیستم در اولویت است و باید قبل از PWA تکمیل شود.

1. **روز 1**: محدودسازی دسترسی ادمین اصلی + اعمال RBAC در تمام API Routes
2. **روز 2**: ایجاد Hook `usePermissions()` و کامپوننت `ProtectedComponent`
3. **روز 3**: مخفی کردن UI بر اساس نقش (دکمه‌ها، منوها)
4. **روز 4**: صفحه مدیریت نقش‌ها + تست کامل

### مرحله 2: پیاده‌سازی PWA (اولویت بالا) — 2-3 روز
**چرا بعد از RBAC؟** PWA برای تجربه کاربری بهتر است، اما امنیت اولویت دارد.

1. **روز 1**: ایجاد manifest.json و آیکون‌ها
2. **روز 2**: پیاده‌سازی Service Worker
3. **روز 3**: تست نصب و Offline mode

### مرحله 3: تست و بهینه‌سازی — 1-2 روز
1. تست RBAC با نقش‌های مختلف
2. تست PWA روی موبایل
3. بهینه‌سازی عملکرد

---

## 📝 نکات مهم

1. **PWA بهتر از اپلیکیشن جداگانه است** برای شروع، چون:
   - یک کد برای وب و موبایل
   - نصب سریع‌تر
   - به‌روزرسانی خودکار
   - بعداً می‌توان به Native App تبدیل کرد (با Capacitor یا TWA)

2. **RBAC باید در Frontend و Backend اعمال شود**:
   - Backend: امنیت اصلی (جلوگیری از دسترسی غیرمجاز)
   - Frontend: تجربه کاربری بهتر (مخفی کردن دکمه‌های غیرمجاز)

3. **محدودسازی ادمین اصلی** برای جلوگیری از قفل شدن سیستم ضروری است:
   - ادمین اصلی نباید بتواند نقش خود را تغییر دهد
   - ادمین اصلی نباید بتواند حساب خود را غیرفعال کند

4. **طبق توضیحات اولیه** (`explaination.md`):
   - نقش‌ها: مدیر کل، مدیر مالی، بازاریاب، مشتری ✅
   - امکان تنظیم دسترسی‌های اختصاصی ✅ (Backend پیاده شده)
   - فعال/غیرفعال کردن کاربران ✅ (در ماژول Marketers)

---

## 🔗 مراجع

- `explaination.md` — خط 7: "وب‌اپ/PWA و پنل مدیریت"
- `explaination.md` — خط 11: "پشتیبانی از PWA"
- `explaination.md` — خط 20: "مدیریت نقش‌ها: مدیر کل، مدیر مالی، بازاریاب، مشتری"
- `todo.md` — فاز 9: پیاده‌سازی PWA
- `todo.md` — فاز 10: تکمیل RBAC
- `lib/middleware/rbac.ts` — پیاده‌سازی Backend RBAC
