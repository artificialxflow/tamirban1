# گزارش جامع وضعیت پروژه تعمیربان

**تاریخ گزارش:** ۱۴۰۴/۰۸/۲۶  
**نسخه پروژه:** 0.1.0  
**وضعیت کلی:** در حال توسعه (حدود ۶۰% تکمیل شده)

---

## 📊 خلاصه اجرایی

### وضعیت کلی ماژول‌ها

| ماژول | وضعیت | درصد تکمیل | اولویت |
|-------|-------|-----------|--------|
| **احراز هویت** | ✅ کامل | ۱۰۰% | ✅ |
| **Customers** | ✅ کامل | ۹۵% | ✅ |
| **Visits** | ✅ کامل | ۸۵% | ✅ |
| **Marketers** | ✅ کامل | ۹۰% | ✅ |
| **Invoices** | ⚠️ در حال توسعه | ۲۰% | 🔴 بالا |
| **SMS Center** | ❌ شروع نشده | ۱۰% | 🟡 متوسط |
| **Reports** | ⚠️ جزئی | ۳۰% | 🟡 متوسط |
| **Dashboard** | ✅ کامل | ۸۵% | ✅ |
| **نقشه نشان** | ❌ شروع نشده | ۰% | 🔴 بالا |

---

## ✅ کارهای انجام شده

### 1. زیرساخت و احراز هویت (۱۰۰% تکمیل)
- ✅ راه‌اندازی Next.js + TypeScript + Tailwind CSS
- ✅ اتصال به MongoDB
- ✅ احراز هویت با OTP و تابان اس‌ام‌اس
- ✅ JWT و Refresh Token
- ✅ Role-Based Access Control (RBAC)
- ✅ Rate Limiting و Error Handling
- ✅ Postman Collection برای Auth

### 2. ماژول Customers (۹۵% تکمیل)
- ✅ CRUD کامل (Create, Read, Update, Delete)
- ✅ فیلتر پیشرفته (وضعیت، شهر، بازاریاب)
- ✅ جستجوی زنده
- ✅ Pagination
- ✅ فرم ایجاد و ویرایش
- ❌ Import/Export Excel (باقی‌مانده)
- ❌ صفحه جزئیات مشتری (باقی‌مانده)

### 3. ماژول Visits (۸۵% تکمیل)
- ✅ CRUD کامل
- ✅ فیلتر بر اساس تاریخ، بازاریاب، وضعیت
- ✅ فرم ثبت/ویرایش ویزیت
- ✅ Persian Date Time Picker
- ✅ Overview و Reminders
- ❌ نقشه نشان (اولویت بالا)
- ❌ تغییر وضعیت از UI (باقی‌مانده)

### 4. ماژول Marketers (۹۰% تکمیل)
- ✅ CRUD کامل
- ✅ Pagination و Sort
- ✅ کارت‌های عملکرد
- ✅ تابلوی امتیاز داینامیک
- ✅ فرم ایجاد/ویرایش
- ❌ نمودار عملکرد (باقی‌مانده)

### 5. Dashboard (۸۵% تکمیل)
- ✅ KPI Cards
- ✅ Today Visits Preview
- ✅ Quick Tasks
- ✅ Stats Overview
- ❌ فیلتر زمانی (باقی‌مانده)

---

## ⚠️ کارهای در حال انجام

### 1. ماژول Invoices (۲۰% تکمیل) 🔴 اولویت بالا
**وضعیت فعلی:**
- ✅ Repository آماده است
- ✅ Types/Interfaces تعریف شده
- ❌ Service کامل نشده
- ❌ API Endpoints پیاده‌سازی نشده
- ❌ فرانت‌اند فقط UI استاتیک دارد
- ❌ PDF Generation پیاده‌سازی نشده

**کارهای لازم:**
1. پیاده‌سازی `invoices.service.ts`:
   - `createInvoice()`
   - `updateInvoice()`
   - `calculateInvoiceTotal()`
   - `markAsPaid()`
   - `listInvoices()` با فیلتر

2. ایجاد API Endpoints:
   - GET /api/invoices (لیست)
   - POST /api/invoices (ایجاد)
   - GET /api/invoices/[id] (جزئیات)
   - PATCH /api/invoices/[id] (ویرایش)
   - DELETE /api/invoices/[id] (حذف)
   - PATCH /api/invoices/[id]/status (تغییر وضعیت)
   - GET /api/invoices/[id]/pdf (دانلود PDF)

3. PDF Generation:
   - نصب کتابخانه (pdfkit یا puppeteer)
   - Template پیش‌فاکتور
   - تولید PDF با داده واقعی

4. فرانت‌اند:
   - اتصال به API
   - فرم ایجاد/ویرایش پیش‌فاکتور
   - پیش‌نمایش PDF
   - تغییر وضعیت پرداخت

**برآورد زمان:** ۶-۹ روز

---

## ❌ کارهای باقی‌مانده (اولویت بالا)

### 1. ادغام نقشه نشان در وب‌اپ 🗺️ 🔴

**وضعیت:** API Key دریافت شده (`web.eaba70d1a1b34fb2a2ad25306e8e58c7`)

**کارهای لازم:**
1. افزودن API Key به `.env.local`
2. نصب کتابخانه نقشه نشان:
   ```bash
   npm install @neshan-maps-platform/neshan-maps-gl
   ```
3. ایجاد کامپوننت `NeshanMap`:
   - نمایش نقشه در صفحه Visits
   - نمایش Marker ویزیت‌ها
   - امکان انتخاب موقعیت
   - ذخیره مختصات در Visit

4. به‌روزرسانی مدل Visit:
   - افزودن فیلد `location` (latitude, longitude)

5. API Endpoints:
   - GET /api/visits/locations (لیست مختصات)
   - POST /api/visits/[id]/location (به‌روزرسانی)

**برآورد زمان:** ۳-۴ روز

---

### 2. ماژول SMS Center (۱۰% تکمیل) 🟡

**وضعیت:** فقط تابان اس‌ام‌اس برای OTP پیاده‌سازی شده

**کارهای لازم:**
1. Service کامل:
   - `sendCampaignSms()`
   - `listSmsLogs()`
   - `createCampaign()`

2. API Endpoints:
   - GET /api/sms/campaigns
   - POST /api/sms/campaigns
   - GET /api/sms/logs
   - POST /api/sms/send

3. فرانت‌اند:
   - لیست کمپین‌ها
   - فرم ایجاد کمپین
   - آمار ارسال‌ها

**برآورد زمان:** ۴ روز

---

### 3. ماژول Reports (۳۰% تکمیل) 🟡

**وضعیت:** فقط Dashboard Overview آماده است

**کارهای لازم:**
1. Service کامل:
   - `getCustomerReports()`
   - `getInvoiceReports()`
   - `getVisitReports()`
   - `exportToExcel()`

2. API Endpoints:
   - GET /api/reports/customers
   - GET /api/reports/invoices
   - GET /api/reports/visits
   - GET /api/reports/export

3. فرانت‌اند:
   - نمودارهای تحلیلی
   - جداول گزارش
   - خروجی Excel/PDF

**برآورد زمان:** ۴-۶ روز

---

## 📱 نیازمندی‌های اندروید (برای فاز بعدی)

### نقشه نشان برای اندروید

**نیازمندی‌ها:**
1. **دریافت API Key اندروید:**
   - ایجاد کلید دسترسی Android در پنل نشان
   - دریافت Bundle Name از تیم اندروید
   - دریافت Sign Key از تیم اندروید
   - ثبت در `.env.example`

2. **مستندسازی:**
   - لینک به مستندات رسمی نشان برای Android SDK
   - مثال‌های کد برای Flutter/Android
   - راهنمای Location Services
   - مجوزهای لازم (AndroidManifest.xml)

3. **API Endpoints:**
   - GET /api/visits/locations (برای نمایش روی نقشه)
   - POST /api/visits/[id]/location (به‌روزرسانی مختصات)
   - GET /api/customers/[id]/location (موقعیت مشتری)

**برآورد زمان:** ۱-۲ روز (بعد از دریافت اطلاعات از تیم اندروید)

---

## 🔧 بهینه‌سازی‌های لازم

### 1. ایندکس‌های MongoDB
- [ ] ایندکس برای `contact.phone` (Customers)
- [ ] ایندکس برای `displayName` (Customers - text search)
- [ ] ایندکس برای `customerId`, `marketerId`, `scheduledAt`, `status` (Visits)
- [ ] ایندکس برای `customerId`, `status`, `dueAt` (Invoices)

**برآورد زمان:** ۰.۵ روز

### 2. Import/Export Excel
- [ ] Import Customers از Excel
- [ ] Export Customers به Excel
- [ ] Export Reports به Excel

**برآورد زمان:** ۲-۳ روز

### 3. تست‌ها
- [ ] Unit Tests (Services)
- [ ] Integration Tests (API Endpoints)
- [ ] E2E Tests (سناریوهای کلیدی)

**برآورد زمان:** ۳-۵ روز

---

## 📅 برآورد زمانی کلی

### کارهای فوری (اولویت بالا)
| کار | زمان برآوردی |
|-----|-------------|
| تکمیل ماژول Invoices | ۶-۹ روز |
| ادغام نقشه نشان (وب) | ۳-۴ روز |
| ایندکس‌های MongoDB | ۰.۵ روز |
| **جمع** | **۹.۵-۱۳.۵ روز** |

### کارهای متوسط (اولویت متوسط)
| کار | زمان برآوردی |
|-----|-------------|
| تکمیل SMS Center | ۴ روز |
| تکمیل Reports | ۴-۶ روز |
| Import/Export Excel | ۲-۳ روز |
| **جمع** | **۱۰-۱۳ روز** |

### کارهای پایین (اولویت پایین)
| کار | زمان برآوردی |
|-----|-------------|
| تست‌های جامع | ۳-۵ روز |
| بهینه‌سازی عملکرد | ۱-۲ روز |
| مستندسازی کامل | ۱-۲ روز |
| **جمع** | **۵-۹ روز** |

### **جمع کل کارهای باقی‌مانده: ۲۴.۵-۳۵.۵ روز کاری**

> توجه: این زمان‌ها برای یک توسعه‌دهنده است. با تیم ۲-۳ نفره می‌توان به ۳-۴ هفته کاهش داد.

---

## 🎯 برنامه پیشنهادی (اولویت‌بندی شده)

### هفته ۱-۲: تکمیل ماژول‌های اصلی
1. **روز ۱-۳:** تکمیل ماژول Invoices (Service + API)
2. **روز ۴-۵:** PDF Generation
3. **روز ۶-۷:** فرانت‌اند Invoices
4. **روز ۸-۱۰:** ادغام نقشه نشان (وب)
5. **روز ۱۱-۱۲:** ایندکس‌های MongoDB
6. **روز ۱۳-۱۴:** تست و رفع باگ

### هفته ۳: ماژول‌های تکمیلی
1. **روز ۱۵-۱۸:** تکمیل SMS Center
2. **روز ۱۹-۲۲:** تکمیل Reports
3. **روز ۲۳-۲۴:** Import/Export Excel

### هفته ۴: بهینه‌سازی و تست
1. **روز ۲۵-۲۷:** تست‌های جامع
2. **روز ۲۸-۲۹:** بهینه‌سازی عملکرد
3. **روز ۳۰:** مستندسازی و آماده‌سازی برای Flutter

---

## 📋 چک‌لیست تحویل MVP

### بک‌اند
- [x] احراز هویت کامل
- [x] Customers API
- [x] Visits API
- [x] Marketers API
- [ ] Invoices API
- [ ] PDF Generation
- [ ] SMS Center API
- [ ] Reports API
- [ ] نقشه نشان API

### فرانت‌اند
- [x] احراز هویت UI
- [x] Customers UI
- [x] Visits UI
- [x] Marketers UI
- [ ] Invoices UI
- [ ] نقشه نشان UI
- [ ] SMS Center UI
- [ ] Reports UI

### تست
- [ ] Unit Tests (۷۰%+ coverage)
- [ ] Integration Tests (۸۰%+ coverage)
- [ ] E2E Tests (سناریوهای کلیدی)
- [ ] Manual Testing

### مستندات
- [x] Postman Collection (Auth, Customers, Visits, Marketers)
- [ ] Postman Collection (Invoices, SMS, Reports)
- [ ] API Documentation
- [ ] راهنمای Flutter/Android

---

## 🔍 نکات مهم

### 1. نقشه نشان
- ✅ API Key وب دریافت شده: `web.eaba70d1a1b34fb2a2ad25306e8e58c7`
- ❌ API Key اندروید: نیاز به Bundle Name و Sign Key از تیم اندروید
- 📖 مستندات: https://platform.neshan.org/docs/

### 2. تابان اس‌ام‌اس
- ✅ ادغام کامل برای OTP
- ❌ SMS Center برای کمپین‌ها: باقی‌مانده

### 3. MongoDB
- ✅ اتصال برقرار است
- ⚠️ ایندکس‌ها: نیاز به بهینه‌سازی

### 4. Postman
- ✅ Collection برای Auth, Customers, Visits, Marketers
- ❌ Collection برای Invoices, SMS, Reports: باقی‌مانده

---

## 📞 تماس و پشتیبانی

برای سوالات یا مشکلات:
- بررسی `todo.md` برای لیست کامل کارها
- بررسی `docs/` برای مستندات تکمیلی
- بررسی `postman/` برای مثال‌های API

---

**آخرین به‌روزرسانی:** ۱۴۰۴/۰۸/۲۶  
**نسخه گزارش:** 1.0

