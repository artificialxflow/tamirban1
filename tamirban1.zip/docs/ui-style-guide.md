# 🎨 UI Style Guide — تعمیربان

این سند پایه مشترک طراحی است تا هر تغییری در فرانت‌اند با زبان بصری یکسان پیش برود. در فاز ۱۲ باید بر اساس این راهنما UI فعلی سبک‌سازی و یکپارچه شود.

## 1. Design Tokens

### 1.1. رنگ‌های اصلی
| Token | Value | استفاده پیشنهادی |
|-------|-------|------------------|
| `primary-500` | `#3b82f6` | دکمه اصلی، لینک‌های تأکیدی |
| `primary-600` | `#2563eb` | Hover / Active دکمه اصلی |
| `accent-500` | `#22c55e` | وضعیت موفق، Badge مثبت |
| `warm-500` | `#f97316` | هشدار نرم، Badge اطلاع‌رسانی |
| `rose-500` | `#f43f5e` (Tailwind) | خطا و حذف |
| `slate-700` | `#334155` | متن اصلی |
| `slate-500` | `#64748b` | متن ثانویه / توضیح |
| `slate-100` | `#f1f5f9` | پس‌زمینه‌های خنثی |

> قاعده: حداکثر دو رنگ برند در هر صفحه استفاده شود. برای تأکید دوم از `accent` یا `warm` استفاده کنید، نه ترکیب هر دو.

### 1.2. گرادیان‌ها و سایه‌ها
- `bg-gradient-primary`: فقط برای کارت‌های KPI و CTA اصلی.
- `shadow-soft`: سایه پیش‌فرض کارت‌ها (در فاز ۱۲ باید میزان Alpha به `0.06` کاهش یابد).
- از `shadow-soft-primary` / `shadow-soft-accent` فقط در Hero یا کارت ویژه استفاده شود؛ در جدول‌ها و مدال‌ها حذف شود.

### 1.3. Border Radius
- `rounded-3xl` (24px) فقط برای کارت‌های ویترین (Dashboard Hero).
- `rounded-2xl` (16px) پیش‌فرض کارت‌ها و مدال‌ها.
- `rounded-xl` (12px) برای فرم‌ها و ورودی‌ها.

## 2. تایپوگرافی
| Element | کلاس Tailwind | اندازه | کاربرد |
|---------|---------------|--------|--------|
| H1 | `text-3xl md:text-4xl font-semibold` | 32-36px | عنوان صفحه اصلی |
| H2 | `text-2xl font-semibold` | 24px | سرفصل بخش‌ها |
| H3 | `text-xl font-semibold` | 20px | عنوان کارت‌ها / مدال‌ها |
| Body | `text-base text-slate-600` | 16px | متن اصلی |
| Caption | `text-sm text-slate-500` | 14px | توضیحات فرم، Badge |

- فاصله عمودی تیتر تا محتوا: `mt-4` برای H1، `mt-3` برای H2.
- در مدال‌ها عنوان همیشه `text-xl font-semibold text-slate-800` باشد.

## 3. فاصله‌گذاری و شبکه
- `section`‌های اصلی: padding افقی `px-6 md:px-8`, عمودی `py-6`.
- Grid دو ستونه فرم‌ها: `gap-4 md:gap-6`. برای موبایل چینش ستونی.
- کارت‌ها داخل Dashboard: `space-y-4`، از تکرار `gap-6` در ستون‌های عمودی خودداری کنید.
- جدول‌ها: سطر `py-3`, سلول افقی `px-5`. سطرها در حالت موبایل باید به Card تبدیل شوند (`flex flex-col gap-2`).

## 4. دکمه‌ها (Button System)
| Variant | کلاس پایه | کاربرد |
|---------|-----------|--------|
| Primary | `bg-primary-500 hover:bg-primary-600 text-white shadow-sm` | اقدام اصلی |
| Secondary | `border border-primary-200 text-primary-700 hover:bg-primary-50` | اقدام مکمل |
| Ghost | `text-slate-600 hover:text-slate-900 hover:bg-slate-100` | لینک بدون تأکید |
| Danger | `bg-rose-500 hover:bg-rose-600 text-white` | حذف / عملیات حساس |

سایزها:
- `sm`: `text-xs px-3 py-1.5 rounded-full` (Tag actions)
- `md`: `text-sm px-4 py-2 rounded-xl` (دکمه عمومی)
- `lg`: `text-base px-5 py-3 rounded-xl` (CTA در مدال‌ها)

> تمام دکمه‌های موجود باید به این سیستم مهاجرت کنند؛ کلاس‌های سفارشی داخل کامپوننت‌ها حذف می‌شود.

## 5. کارت‌ها و مدال‌ها
- پس‌زمینه: `bg-white` یا `bg-slate-50` (حداکثر دو Level).
- حذف گرادیان پس‌زمینه از تمامی کارت‌های لیست (به جز KPI).
- سایه پیش‌فرض: `shadow-sm shadow-slate-100/80`.
- Padding داخلی کارت استاندارد: `p-5`، در مدال‌ها `p-6`.
- CTA footer مدال‌ها: `flex items-center justify-end gap-3 border-t border-slate-100 pt-4 mt-4`.

## 6. Empty / Loading States
- Empty state: کارت با `border-dashed border-slate-200 rounded-2xl p-8 text-center` + آیکون خط‌دار.
- Loading: استفاده از Skeleton (`animate-pulse bg-slate-200/70 h-4 rounded-full`). اسپینر تنها برای سناریوهای کوتاه.
- Error: `bg-rose-50 border border-rose-200 text-rose-700 rounded-2xl px-4 py-3`.

## 7. آیکون‌ها
- منبع پیشنهادی: Heroicons Solid.
- اندازه ثابت در جدول‌ها و لیست‌ها: 16px (`w-4 h-4`). در کارت‌های KPI حداکثر 24px.
- در مدال‌ها آیکون حذف شود مگر کاربرد مشخص (مثلاً هشدار حذف).

## 8. چک‌لیست سبک‌سازی فاز ۱۲
1. **مستندسازی رنگ‌ها و تایپوگرافی** (این سند) ✅
2. تعریف کامپوننت Button مشترک و جایگزینی همه دکمه‌ها.
3. بازطراحی کارت‌ها و مدال‌ها با سایه سبک.
4. بازبینی جدول‌های Customers/Visits/Invoices و افزودن حالت Card در موبایل.
5. افزودن Empty/Loading states در لیست‌ها.
6. یکپارچه‌سازی آیکون‌ها و حذف نمونه‌های اضافی.
7. ثبت نتایج تست دستی در `docs/ui-review-report.md`.

---
هر تغییر UI باید ابتدا با این راهنما تطبیق داده شده و سپس در PR به آن ارجاع شود. در صورت نیاز به استثنا، توضیح در همین فایل اضافه گردد.

