# 📦 راهنمای Handoff برای تیم اندروید

این سند توضیح می‌دهد چگونه بسته استاتیک تولید شده در پروژه وب را در پروژه مستقل (Flutter یا هر فریم‌ورک دیگری) مصرف کنید.

## 1. ساختار فولدر `handoff/`
- `handoff/static-ui/`
  - `index.html`, `customers.html`, ... (صفحات کلیدی)
  - `assets/styles.css` (خروجی Tailwind RTL)
  - `assets/scripts.js` (اسکریپت‌های ساده برای تعاملات پایه)
  - `mock-data/*.json` (داده‌های نمونه برای جداول و کارت‌ها)
  - `screenshots/` (اسکرین‌شات در رزولوشن‌های مختلف)
- `handoff/api/`
  - `tamirban.postman_collection.json`
  - `tamirban.postman_environment.json`
  - `api-reference.md`
- `handoff/prompt/mobile-implementation.md`

## 2. نحوه استفاده
1. صفحات HTML را می‌توان مستقیماً در مرورگر باز کرد و به عنوان مرجع UI استفاده نمود.
2. فایل CSS شامل تمام کلاس‌های Tailwind مورد استفاده است؛ در صورت نیاز می‌توان آن را در پروژه موبایل به عنوان Style Token به کار گرفت.
3. اسکریپت‌ها صرفاً برای نمایش نمونه هستند؛ منطق واقعی باید در اپلیکیشن اندروید پیاده‌سازی شود.

## 3. فرایند پیشنهاد شده
1. مطالعه `docs/ui-style-guide.md` برای آشنایی با Design Tokens.
2. مرور `handoff/static-ui/style-guide.md` برای جزئیات پیاده‌سازی هر صفحه.
3. وارد کردن Postman Collection و بررسی سناریوهای API.
4. استفاده از `handoff/prompt/mobile-implementation.md` به عنوان نقشه راه توسعه.

> هرگونه تغییر در UI وب باید در همین سند و فولدر Handoff بازتاب داده شود تا تیم اندروید نسخه به‌روزشده را دریافت کند.

