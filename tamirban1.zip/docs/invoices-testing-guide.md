# راهنمای تست ماژول Invoices

این راهنما مراحل تست ماژول Invoices را توضیح می‌دهد.

## ✅ کارهای انجام شده

1. ✅ **Service کامل** (`lib/services/invoices.service.ts`)
   - `createInvoice()` - ایجاد پیش‌فاکتور
   - `updateInvoice()` - به‌روزرسانی پیش‌فاکتور
   - `calculateInvoiceTotal()` - محاسبه خودکار مبالغ
   - `listInvoices()` - لیست با فیلتر و Pagination
   - `getInvoiceById()` - دریافت جزئیات
   - `changeInvoiceStatus()` - تغییر وضعیت
   - `markInvoiceAsPaid()` - علامت‌گذاری به عنوان پرداخت شده
   - `deleteInvoice()` - حذف

2. ✅ **API Endpoints**
   - `GET /api/invoices` - لیست پیش‌فاکتورها
   - `POST /api/invoices` - ایجاد پیش‌فاکتور
   - `GET /api/invoices/[id]` - جزئیات پیش‌فاکتور
   - `PATCH /api/invoices/[id]` - به‌روزرسانی
   - `DELETE /api/invoices/[id]` - حذف
   - `PATCH /api/invoices/[id]/status` - تغییر وضعیت
   - `GET /api/invoices/[id]/pdf` - دانلود PDF

3. ✅ **PDF Generation** (`lib/utils/pdf-generator.ts`)
   - تولید PDF با pdfkit
   - فرمت فارسی برای تاریخ و اعداد
   - نمایش کامل اطلاعات پیش‌فاکتور

---

## 🧪 مراحل تست

### مرحله 1: تست API با Postman

#### 1.1. دریافت لیست پیش‌فاکتورها

**Request:**
```
GET http://localhost:3000/api/invoices
Headers:
  Authorization: Bearer {YOUR_JWT_TOKEN}
```

**Query Parameters (اختیاری):**
- `status`: DRAFT, SENT, PAID, OVERDUE, CANCELLED
- `customerId`: شناسه مشتری
- `marketerId`: شناسه بازاریاب
- `startDate`: تاریخ شروع (ISO format)
- `endDate`: تاریخ پایان (ISO format)
- `page`: شماره صفحه (پیش‌فرض: 1)
- `limit`: تعداد در هر صفحه (پیش‌فرض: 20)

**Response (موفق):**
```json
{
  "success": true,
  "data": {
    "data": [],
    "total": 0,
    "page": 1,
    "limit": 20
  }
}
```

---

#### 1.2. ایجاد پیش‌فاکتور جدید

**Request:**
```
POST http://localhost:3000/api/invoices
Headers:
  Authorization: Bearer {YOUR_JWT_TOKEN}
  Content-Type: application/json
```

**Body:**
```json
{
  "customerId": "CUSTOMER_ID_HERE",
  "marketerId": "MARKETER_ID_HERE",
  "status": "DRAFT",
  "issuedAt": "2024-01-15T10:00:00.000Z",
  "dueAt": "2024-01-22T10:00:00.000Z",
  "currency": "IRR",
  "items": [
    {
      "title": "سرویس دوره‌ای تجهیزات",
      "quantity": 1,
      "unit": "بسته",
      "unitPrice": 18000000,
      "taxRate": 9,
      "discount": 0
    },
    {
      "title": "قطعات مصرفی ماهانه",
      "quantity": 6,
      "unit": "عدد",
      "unitPrice": 2500000,
      "taxRate": 9,
      "discount": 0
    }
  ],
  "paymentReference": null
}
```

**Response (موفق):**
```json
{
  "success": true,
  "message": "پیش‌فاکتور با موفقیت ایجاد شد.",
  "data": {
    "_id": "INVOICE_ID",
    "customerId": "CUSTOMER_ID",
    "status": "DRAFT",
    "subtotal": 33000000,
    "taxTotal": 2970000,
    "discountTotal": 0,
    "grandTotal": 35970000,
    "items": [...],
    "meta": {
      "invoiceNumber": "INV-202401-1234"
    }
  }
}
```

**نکات مهم:**
- `customerId` باید یک شناسه معتبر از جدول Customers باشد
- `marketerId` اختیاری است
- `items` باید حداقل یک آیتم داشته باشد
- مبالغ به صورت خودکار محاسبه می‌شوند

---

#### 1.3. دریافت جزئیات پیش‌فاکتور

**Request:**
```
GET http://localhost:3000/api/invoices/{INVOICE_ID}
Headers:
  Authorization: Bearer {YOUR_JWT_TOKEN}
```

**Response (موفق):**
```json
{
  "success": true,
  "data": {
    "_id": "INVOICE_ID",
    "customerId": "CUSTOMER_ID",
    "customerName": "نام مشتری",
    "status": "DRAFT",
    "items": [...],
    "grandTotal": 35970000,
    ...
  }
}
```

---

#### 1.4. به‌روزرسانی پیش‌فاکتور

**Request:**
```
PATCH http://localhost:3000/api/invoices/{INVOICE_ID}
Headers:
  Authorization: Bearer {YOUR_JWT_TOKEN}
  Content-Type: application/json
```

**Body (فقط فیلدهای مورد نیاز):**
```json
{
  "status": "SENT",
  "items": [
    {
      "title": "سرویس دوره‌ای تجهیزات",
      "quantity": 2,
      "unit": "بسته",
      "unitPrice": 18000000,
      "taxRate": 9,
      "discount": 1000000
    }
  ]
}
```

**نکته:** در صورت تغییر `items`، مبالغ به صورت خودکار دوباره محاسبه می‌شوند.

---

#### 1.5. تغییر وضعیت پیش‌فاکتور

**Request:**
```
PATCH http://localhost:3000/api/invoices/{INVOICE_ID}/status
Headers:
  Authorization: Bearer {YOUR_JWT_TOKEN}
  Content-Type: application/json
```

**Body:**
```json
{
  "status": "PAID",
  "paidAt": "2024-01-20T10:00:00.000Z"
}
```

**وضعیت‌های مجاز:**
- `DRAFT` - پیش‌نویس
- `SENT` - ارسال شده
- `PAID` - پرداخت شد
- `OVERDUE` - معوق
- `CANCELLED` - لغو شد

---

#### 1.6. دانلود PDF پیش‌فاکتور

**Request:**
```
GET http://localhost:3000/api/invoices/{INVOICE_ID}/pdf
Headers:
  Authorization: Bearer {YOUR_JWT_TOKEN}
```

**Response:**
- Content-Type: `application/pdf`
- فایل PDF به صورت مستقیم دانلود می‌شود

**تست در Postman:**
1. Request را ارسال کنید
2. در Response، روی "Send and Download" کلیک کنید
3. فایل PDF را ذخیره کنید
4. فایل را باز کنید و محتوا را بررسی کنید

---

#### 1.7. حذف پیش‌فاکتور

**Request:**
```
DELETE http://localhost:3000/api/invoices/{INVOICE_ID}
Headers:
  Authorization: Bearer {YOUR_JWT_TOKEN}
```

**Response (موفق):**
```json
{
  "success": true,
  "message": "پیش‌فاکتور با موفقیت حذف شد.",
  "data": null
}
```

---

### مرحله 2: تست از طریق UI (بعد از تکمیل فرانت‌اند)

1. **ورود به سیستم**
   - وارد صفحه `/auth` شوید
   - با شماره موبایل و OTP وارد شوید

2. **دسترسی به صفحه Invoices**
   - از منوی سمت راست، "پیش‌فاکتورها" را انتخاب کنید
   - صفحه `/dashboard/invoices` باز می‌شود

3. **ایجاد پیش‌فاکتور جدید**
   - روی دکمه "ایجاد پیش‌فاکتور جدید" کلیک کنید
   - فرم را پر کنید
   - پیش‌فاکتور را ذخیره کنید

4. **مشاهده لیست**
   - لیست پیش‌فاکتورها را بررسی کنید
   - فیلترها را تست کنید

5. **دانلود PDF**
   - روی یک پیش‌فاکتور کلیک کنید
   - دکمه "دانلود PDF" را بزنید
   - فایل PDF را بررسی کنید

---

## 🔍 بررسی خطاها

### خطاهای رایج:

1. **401 Unauthorized**
   - مشکل: توکن JWT معتبر نیست یا منقضی شده
   - راه‌حل: دوباره وارد شوید و توکن جدید دریافت کنید

2. **404 Not Found**
   - مشکل: شناسه پیش‌فاکتور یا مشتری معتبر نیست
   - راه‌حل: از شناسه‌های معتبر استفاده کنید

3. **422 Validation Error**
   - مشکل: داده‌های ارسالی معتبر نیستند
   - راه‌حل: فیلدهای اجباری را پر کنید و فرمت‌ها را بررسی کنید

4. **500 Internal Server Error**
   - مشکل: خطای سرور
   - راه‌حل: لاگ‌های سرور را بررسی کنید

---

## 📝 چک‌لیست تست

- [ ] ایجاد پیش‌فاکتور با موفقیت
- [ ] محاسبه خودکار مبالغ (subtotal, tax, grandTotal)
- [ ] دریافت لیست پیش‌فاکتورها
- [ ] فیلتر بر اساس وضعیت
- [ ] فیلتر بر اساس مشتری
- [ ] فیلتر بر اساس بازاریاب
- [ ] فیلتر بر اساس تاریخ
- [ ] Pagination
- [ ] دریافت جزئیات پیش‌فاکتور
- [ ] به‌روزرسانی پیش‌فاکتور
- [ ] تغییر وضعیت پیش‌فاکتور
- [ ] دانلود PDF
- [ ] حذف پیش‌فاکتور
- [ ] Validation خطاها
- [ ] Authentication خطاها

---

## 🚀 مراحل بعدی

بعد از تست موفق API:
1. تکمیل فرانت‌اند (اتصال UI به API)
2. افزودن فرم ایجاد/ویرایش پیش‌فاکتور
3. افزودن Pagination در UI
4. افزودن فیلترها در UI
5. افزودن دکمه دانلود PDF

---

**آخرین به‌روزرسانی:** ۱۴۰۴/۰۸/۲۶

