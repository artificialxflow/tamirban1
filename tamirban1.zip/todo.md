# چک‌لیست جامع اجرای پروژه «تعمیربان» (شروع از صفر)

این سند برای شروع پروژه جدید در محیط Next.js + TypeScript + Tailwind تدوین شده است و باید در مخزن تازه‌ ایجادشده قرار گیرد. همه آیتم‌ها در حالت انجام‌نشده هستند تا بتوان روند را مرحله‌به‌مرحله دنبال کرد.

## فاز 0 — هماهنگی و پیش‌نیازها
- [ ] تایید محدوده و خروجی‌ها بر اساس `explaination.md`
- [ ] مشخص کردن نقش‌ها، زمان‌بندی و نحوه گزارش‌دهی
- [ ] انتخاب سرویس پیامکی و دریافت دسترسی‌ها (در صورت آماده نبودن، ثبت در لیست تعلیق)
- [ ] دریافت قالب فایل Excel برای Import مشتری‌ها از کارفرما
- [ ] هماهنگی با هاست سی‌پنل برای اجرای برنامه Node.js روی پورت 3124 و دسترسی به SSH/FTP

## فاز 1 — راه‌اندازی پروژه Next.js (Tailwind + TypeScript)
- [x] ساخت مخزن جدید و اجرای `npx create-next-app@latest tamirban --ts --tailwind`
- [x] پاک‌سازی نمونه‌ها و تعریف ساختار پوشه‌ها (`app/`, `lib/`, `modules/`, `postman/`, `public/`, `docs/`)
- [x] افزودن فونت «ایران یکان» در `public/fonts` و تعریف آن در `tailwind.config.ts`
- [x] تنظیم زبان فارسی و RTL در `app/layout.tsx` و `app/globals.css`
- [x] پیکربندی Theme پایه (رنگ‌ها، سایه‌ها، spacing) با Tailwind
- [ ] راه‌اندازی ESLint/Prettier و فعال‌سازی TypeScript strict mode
- [x] ایجاد `postman/README.md` برای آماده‌سازی کالکشن‌ها و مستندات API

## فاز 2 — تنظیمات محیطی و استقرار سی‌پنل
- [x] ایجاد `.env.example` با متغیرهای پایه (PORT=3124، NEXT_PUBLIC_SITE_URL، MONGODB_URI، SMS Provider)
- [x] پیاده‌سازی `server.js` برای اجرای Next.js روی پورت 3124 با `next start`
- [x] افزودن اسکریپت `start:server` به `package.json`
- [x] تست اجرای محلی با `node server.js`
- [x] نوشتن راهنمای استقرار در `docs/deployment-cpanel.md`

## فاز 3 — طراحی UI پایه با تایید مرحله‌ای
- [x] طراحی Layout اصلی (Header، Sidebar، Main) و نمایش به کارفرما برای تایید
- [x] تنظیم تایپوگرافی و مقیاس فونت‌ها (فونت ایران یکان) و تایید
- [x] پیاده‌سازی UI صفحه ورود/OTP (بدون بک‌اند) و دریافت تایید
- [x] پیاده‌سازی UI صفحه داشبورد (بدون داده واقعی) و دریافت تایید
- [x] طراحی UI صفحات Customers، Marketers، Visits، Invoices، Settings (UI-only) و تایید تک‌به‌تک
  - [x] Customers: لیست، فیلتر و پنل جزئیات
  - [x] Marketers: لیست بازاریاب‌ها و کارت‌های وضعیت
  - [x] Visits: نقشه و جدول برنامه روزانه
  - [x] Invoices: جدول و پیش‌نمایش PDF
  - [x] Settings: تب‌بندی تنظیمات دسترسی و اعلان‌ها
- [x] ساخت کتابخانه کامپوننت‌ها (Buttons، Inputs، Cards، Tables، Tabs، Modals) ✅
  - [x] Modal/Dialog (با backdrop و animation) ✅
  - [x] SearchableSelect (جستجو و انتخاب) ✅
  - [x] PersianDateTimePicker (تاریخ شمسی) ✅
  - [x] Pagination (قبلی/بعدی، شماره صفحه) ✅
- [x] تست ریسپانسیو و RTL در هر مرحله پیش از اتصال به داده ✅

## فاز 4 — مدل داده و اتصال MongoDB
- [x] تعریف Types/Interfaces برای User، Contact، Visit، Product، Invoice، SMSLog
- [x] راه‌اندازی اتصال به MongoDB با URI پروژه و تست سلامت اتصال
- [x] ایجاد لایه Repository/Service برای عملیات CRUD و فیلترها
- [ ] نوشتن تست‌های واحد برای سرویس‌ها (Jest یا Vitest)
- [x] مستندسازی ساختار داده در `docs/data-model.md`

## فاز 5 — احراز هویت و مدیریت نقش‌ها
- [x] پیاده‌سازی احراز هویت با شماره موبایل و OTP (حالت تست: کد ثابت بدون SMS واقعی)
- [ ] **ادغام تابان اس‌ام‌اس برای ارسال OTP واقعی**
  - [ ] افزودن متغیرهای محیطی تابان اس‌ام‌اس به `.env.example` (API_KEY، BASE_URL، SENDER_NUMBER)
  - [ ] ایجاد کلاینت تابان اس‌ام‌اس در `lib/vendors/taban-sms.ts` با توابع ارسال SMS
  - [ ] بررسی مستندات API تابان برای endpoint ارسال SMS و ساختار درخواست/پاسخ
  - [ ] پیاده‌سازی `sendOtpSms(phone, code)` با استفاده از API Key در هدر Authorization
  - [ ] به‌روزرسانی `lib/services/otp.service.ts` برای فراخوانی سرویس واقعی به جای کد ثابت
  - [ ] مدیریت خطاهای ارسال SMS (شبکه، اعتبار، محدودیت نرخ) و پیام‌های مناسب به کاربر
  - [ ] ثبت لاگ ارسال در کالکشن `SMSLog` با وضعیت QUEUED/DELIVERED/FAILED
  - [ ] تست ارسال واقعی با شماره موبایل و بررسی دریافت پیامک
  - [ ] حذف بازگرداندن کد OTP از پاسخ API در محیط Production
- [x] هش کردن OTPها و رمزهای یک‌بارمصرف با `bcrypt`
- [x] صدور و مدیریت توکن‌های دسترسی/تازه‌سازی با `JWT`
- [x] مستندسازی گزینه جایگزین (NextAuth Credentials) و دلیل انتخاب رویکرد JWT ✅
- [ ] صفحه مدیریت کاربران: ایجاد دستی بازاریاب، فعال/غیرفعال، تعیین نقش و دسترسی اختصاصی
- [x] پیاده‌سازی Role-Based Access Control در سطح API و UI ✅
- [x] ثبت لاگ ورود/خروج و رویدادهای امنیتی ✅

## فاز 6 — ماژول‌های اصلی پنل وب
- [x] **Customers:** CRUD کامل، جستجو و فیلتر ✅ (باقی: Import/Export Excel، جزئیات مشتری)
- [x] **Marketers:** مدیریت حساب بازاریاب‌ها، تعیین سطح دسترسی، وضعیت فعال/غیرفعال ✅ (باقی: نمودار عملکرد)
- [ ] **Catalog:** مدیریت محصولات، قیمت، دسته‌بندی و تصاویر
- [x] **Visits:** ثبت ویزیت، یادداشت، پیگیری و نیازسنجی ✅ (باقی: نقشه نشان، تغییر وضعیت)
- [ ] **Invoices:** ایجاد/ویرایش، محاسبه، وضعیت‌ها، تولید PDF داخلی و دانلود (اولویت بالا)
- [ ] **SMS Center:** ارسال پیامک فعال‌سازی و تبلیغاتی، لیست ارسال‌ها و وضعیت
- [x] **Dashboard:** نمایش KPI، نمودارها، کارت‌های وضعیت ✅ (باقی: فیلتر زمانی)
- [ ] ارائه دموی هر ماژول به کارفرما پس از اتصال داده برای تایید نهایی UI/UX

## فاز 7 — API RESTful و Postman
- [ ] طراحی ساختار Endpointها، متدها و پاسخ‌ها برای همه ماژول‌ها
- [ ] پیاده‌سازی Route Handlerهای Next.js با Middlewareهای احراز هویت، Validation، Rate Limit
- [ ] ساخت Postman Collection با مثال درخواست/پاسخ
- [ ] ایجاد Postman Environment (پایه URL، توکن، شماره تست OTP)
- [ ] افزودن تست‌های Postman (pre-request و test scripts)
- [ ] اشتراک‌گذاری مستندات و کالکشن با تیم Flutter/Android

## فاز 8 — آماده‌سازی انتقال به Flutter/Android

### نیازمندی‌های اندروید برای نقشه نشان 📱
- [ ] **دریافت API Key نشان برای اندروید**
  - [ ] ایجاد کلید دسترسی Android در پنل نشان (platform.neshan.org/panel/api-key)
  - [ ] دریافت Bundle Name و Sign Key از تیم اندروید
  - [ ] ثبت کلید Android در `.env.example` (NESHAN_ANDROID_API_KEY)
  - [ ] مستندسازی تفاوت API Key وب و اندروید
- [ ] **مستندسازی API نشان برای اندروید**
  - [ ] لینک به مستندات رسمی نشان برای Android SDK
  - [ ] مثال‌های کد برای نمایش نقشه در Flutter/Android
  - [ ] راهنمای استفاده از Location Services در اندروید
  - [ ] مجوزهای لازم (Location, Internet) در AndroidManifest.xml
- [ ] **API Endpoints برای نقشه**
  - [ ] GET /api/visits/locations (لیست مختصات ویزیت‌ها برای نمایش روی نقشه)
  - [ ] POST /api/visits/[id]/location (به‌روزرسانی مختصات ویزیت)
  - [ ] GET /api/customers/[id]/location (موقعیت مشتری)

### آماده‌سازی عمومی Flutter
- [ ] جمع‌آوری دارایی‌های UI نهایی (تصاویر استاتیک صفحات، Style Guide، Tokenهای Tailwind)
- [ ] تولید راهنمای `docs/flutter-handoff.md` شامل معماری، قراردادهای API، نقش‌ها و سناریوها
- [ ] استخراج نمونه درخواست/پاسخ Postman و الحاق به راهنما
- [ ] تدوین چک‌لیست فازبندی شده توسعه Flutter (Bootstrap → Auth → ماژول‌ها → تست → انتشار)
- [ ] مستندسازی نیازهای امنیتی موبایل (ذخیره JWT/Refresh، مدیریت انقضا، Re-auth)
- [ ] تهیه پرامپت‌ها یا توضیحات استاتیک برای انتقال به تیم طراحی/توسعه موبایل

## فاز 9 — اپلیکیشن Flutter/Android (پس از تحویل راهنمای انتقال)
- [ ] ایجاد پروژه Flutter جدید و تنظیمات اولیه
- [ ] اتصال به REST API (حالت تست OTP) و پیاده‌سازی مدیریت JWT/Refresh Token
- [ ] پیاده‌سازی صفحات Auth، Dashboard، Customers، Visits، Invoices مطابق راهنمای وب
- [ ] **ادغام نقشه نشان در Flutter/Android**
  - [ ] نصب پکیج neshan_map_sdk یا استفاده از WebView با API Key اندروید
  - [ ] پیاده‌سازی صفحه نقشه برای نمایش ویزیت‌ها
  - [ ] استفاده از Location Services برای دریافت موقعیت کاربر
  - [ ] نمایش Marker ویزیت‌ها روی نقشه
  - [ ] امکان انتخاب موقعیت برای ویزیت جدید
  - [ ] ذخیره مختصات در API
- [ ] ادغام Push Notification و مدیریت Device Token
- [ ] تست عملکرد و UI روی دستگاه‌های اندرویدی هدف
- [ ] همگام‌سازی راهنمای انتقال در صورت اعمال تغییر در تجربه کاربری

## فاز 10 — تضمین کیفیت و امنیت
- [ ] پوشش تست‌های واحد و Integration برای وب و API
- [ ] اجرای تست‌های End-to-End (Playwright یا Cypress)
- [ ] تست دستی در موبایل، تبلت و دسکتاپ (RTL + PWA)
- [ ] بررسی امنیتی (Rate Limit، Validation، Sanitization، مدیریت session)
- [ ] آزمون کارایی (پاسخ API، ایجاد PDF، Import/Export Excel)
- [ ] تهیه ویدئوی آموزشی و راهنمای کاربری
- [ ] ممیزی پایگاه داده و ارتباطات (بررسی روابط، ایندکس‌ها، محدودیت‌ها و کفایت داده)
- [ ] بازبینی سناریوهای CRM انتها به انتها (ایجاد کاربر → ویزیت → پیش‌فاکتور → گزارش)

## فاز 11 — استقرار و تحویل
- [ ] ساخت Build نهایی (`next build`)
- [ ] استقرار روی سی‌پنل با `node server.js` و پورت 3124
- [ ] اتصال دامنه `https://tamirban1.ir/` به برنامه Node.js (تنظیمات ریورس پراکسی یا Application Manager)
- [ ] تنظیم و تست SSL روی دامنه
- [ ] قرار دادن `.env` نهایی روی سرور (عدم انتشار در مخزن)
- [ ] تست نهایی روی محیط واقعی برای همه سناریوهای کلیدی
- [ ] تحویل Postman Collection و Environment به تیم اندروید
- [ ] توافق بر برنامه پشتیبانی و به‌روزرسانی‌های آینده

## پیگیری و مستندسازی
- [ ] به‌روزرسانی منظم `todo.md` و `explaination.md` با پیشرفت واقعی
- [ ] ثبت تصمیمات معماری در `docs/architecture.md`
- [ ] نگهداری CHANGELOG برای نسخه‌های مهم
- [ ] دیدار/جلسه دوره‌ای با کارفرما جهت تایید UI و عملکرد
- [ ] آماده‌سازی چک‌لیست تحویل نهایی برای اطمینان از پوشش همه موارد

## رفع فوری — احیای استایل Tailwind
- [x] تصمیم نهایی در مورد مسیر مهاجرت Tailwind (بازگشت به v3 یا تکمیل v4)
- [x] به‌روزرسانی وابستگی‌ها و پیکربندی مطابق مسیر انتخاب‌شده
  - [ ] بازگشت به v3: حذف بسته‌های نسخه ۴، نصب `tailwindcss@^3`, `autoprefixer` و تنظیم مجدد `postcss.config`/`tailwind.config`
  - [x] تکمیل مهاجرت v4: نصب `@tailwindcss/cli`, به‌روزرسانی ورودی CSS (`@import "tailwindcss"`)، تنظیم اسکریپت‌های build/dev و اطمینان از اجرای CLI
- [x] اجرای `next build` یا `next dev` و بررسی خروجی CSS برای وجود utilityها (نمونه: `bg-white`, `rounded-3xl`)
- [x] تست دستی صفحات داشبورد و احراز هویت برای تایید بازگشت استایل‌ها

## رفع فوری — بهبود استایل و فونت (فاز جاری)
- [x] بررسی و رفع مشکل فونت‌های ایران یکان (404 errors)
- [x] بهبود contrast و وضوح دکمه‌ها (تبدیل border-primary-200 به border-primary-300)
- [x] تبدیل همه bg-sky-* به primary colors
- [x] بهبود استایل منو (رفع بی‌رنگ شدن)
- [x] بهبود استایل badgeها و جداول
- [ ] بررسی نهایی و تست در مرورگر

## وظایف فوری — تست اتصال دیتابیس و ورود OTP
- [x] اطمینان از مقداردهی متغیرهای محیطی (`MONGODB_URI`, `MONGODB_DB_NAME`, `JWT_SECRET`) در `.env.local`
- [x] پیاده‌سازی سرویس OTP ساده با `bcrypt` برای ذخیره کدهای یکبارمصرف و محدودیت تلاش‌ها
- [x] ایجاد API برای درخواست OTP و تأیید آن (ثبت کاربر در MongoDB در صورت نبود)
- [x] تولید و بازگرداندن JWT پس از تایید کد `0000` و ذخیره نشست در دیتابیس
- [x] سنجش اتصال با این سناریو: ثبت شماره آزمایشی، ارسال کد ثابت `0000`, دریافت پاسخ موفق از API و ورود از طریق فرانت‌اند
- [x] مستندسازی مراحل تست و ابزارهای Postman جهت استفاده مجدد

## فاز ادغام تابان اس‌ام‌اس — ثبت‌نام و لاگین با OTP واقعی
- [x] **مرحله 1: آماده‌سازی محیط و مستندات**
  - [x] افزودن متغیرهای محیطی تابان به `.env.example` (BASE_URL، API_KEY)
  - [x] دریافت شماره خط خدماتی (SENDER_NUMBER=3000505) از پنل تابان و افزودن به `.env.example`
  - [x] بررسی مستندات API تابان: https://ippanelcom.github.io/Edge-Document/docs/
  - [x] بررسی endpoint Webservice SMS: POST /api/send با sending_type="webservice"
  - [x] به‌روزرسانی `taban-sms-integration.md` با اطلاعات واقعی
- [x] **مرحله 2: پیاده‌سازی کلاینت تابان**
  - [x] ایجاد پوشه `lib/vendors/` در صورت عدم وجود
  - [x] ایجاد فایل `lib/vendors/taban-sms.ts` با تابع `sendSms(phone, message)` و `sendOtpSms(phone, code)`
  - [x] پیاده‌سازی احراز هویت با API Key در هدر `Authorization: {apiKey}`
  - [x] بررسی endpoint ارسال SMS از مستندات: POST `/api/send` با `sending_type="webservice"`
  - [x] پیاده‌سازی ساختار درخواست HTTP (POST) با body مناسب (from_number, message, recipients)
  - [x] تبدیل شماره‌ها به فرمت E.164 (+98...)
  - [x] Parse کردن پاسخ API و استخراج messageId یا کد خطا
  - [x] مدیریت خطاهای شبکه و timeout
- [x] **مرحله 3: اتصال به سرویس OTP**
  - [x] به‌روزرسانی `lib/services/otp.service.ts` در تابع `requestOtp`
  - [x] تولید کد OTP تصادفی (4 رقمی) به جای کد ثابت
  - [x] پس از تولید کد OTP، فراخوانی `sendOtpSms` با شماره و متن پیام
  - [x] ساخت متن پیام OTP: "کد ورود شما: {code}\n\nاین کد تا 5 دقیقه معتبر است."
  - [x] در صورت موفقیت ارسال: ثبت لاگ در `SMSLog` با وضعیت `QUEUED`
  - [x] در صورت خطا: ثبت لاگ با وضعیت `FAILED` و throw کردن خطا (در Production)
  - [x] حذف بازگرداندن کد OTP از پاسخ API در Production
  - [x] حفظ حالت تست با کد `0000` در محیط Development
- [x] **مرحله 4: مدیریت خطا و لاگ**
  - [x] پیاده‌سازی try-catch در `sendSms` برای خطاهای شبکه
  - [x] بررسی کدهای خطای API تابان و تبدیل به پیام‌های کاربرپسند
  - [x] ثبت جزئیات خطا در console برای دیباگ
  - [x] استفاده از `smsLogsRepository.create()` برای ثبت هر ارسال
  - [x] ذخیره `providerMessageId` (messageId) از پاسخ API در رکورد SMSLog
- [x] **مرحله 5: تست و اعتبارسنجی**
  - [x] به‌روزرسانی route handler برای حذف کد در Production
  - [ ] تست واحد برای `sendSms` با Mock Response (اختیاری)
  - [ ] تست یکپارچگی: درخواست OTP از طریق Postman یا UI
  - [ ] تست واقعی: ارسال OTP به شماره موبایل و بررسی دریافت
  - [ ] تست تأیید کد و ورود موفق پس از دریافت پیامک
  - [ ] تست خطا: API Key نامعتبر، شماره نامعتبر، موجودی ناکافی
  - [ ] بررسی ثبت لاگ‌ها در دیتابیس (SMSLog collection)
- [ ] **مرحله 6: بهینه‌سازی و مستندسازی**
  - [x] افزودن Rate Limiting برای جلوگیری از ارسال بیش از حد ✅
  - [ ] به‌روزرسانی `docs/authentication-plan.md` با جزئیات تابان
  - [ ] افزودن مثال‌های Postman برای تست API
  - [ ] مستندسازی کدهای خطا و راه‌حل‌های رایج در `taban-sms-integration.md`
  - [ ] بررسی و تست در محیط Production قبل از استقرار نهایی

## فاز 5.5 — تکمیل احراز هویت و زیرساخت امنیتی

### بک‌اند — احراز هویت و امنیت
- [x] **Middleware احراز هویت JWT** ✅
  - [x] ایجاد `lib/middleware/auth.ts` برای بررسی JWT ✅
  - [x] بررسی اعتبار توکن و استخراج payload ✅
  - [x] مدیریت خطاهای انقضای توکن ✅
  - [x] محافظت از Route Handlers با middleware ✅
- [x] **Refresh Token API** ✅
  - [x] POST /api/auth/refresh (دریافت refreshToken و صدور token جدید) ✅
  - [x] ذخیره refreshToken در دیتابیس یا Redis ✅
  - [x] مدیریت انقضای refreshToken ✅
  - [x] باطل کردن refreshToken در logout ✅
- [x] **Logout API** ✅
  - [x] POST /api/auth/logout (باطل کردن token و refreshToken) ✅
  - [x] ثبت لاگ خروج ✅
- [x] **Role-Based Access Control (RBAC)** ✅
  - [x] Middleware بررسی نقش کاربر ✅
  - [x] تعریف permissions برای هر نقش ✅
  - [x] محافظت از endpoints بر اساس نقش ✅
- [x] **Error Handler مرکزی** ✅
  - [x] ساختار یکپارچه خطا (`{success, message, code, errors}`) ✅
  - [x] کدهای خطای استاندارد ✅
  - [x] Logging خطاها ✅
- [x] **Rate Limiting** ✅
  - [x] Rate limit برای OTP (5 بار در ساعت) ✅
  - [x] Rate limit برای API endpoints ✅
- [x] **CORS Configuration** ✅
  - [x] تنظیم CORS برای Flutter/Web ✅
  - [x] Whitelist دامنه‌های مجاز ✅

### فرانت‌اند — مدیریت نشست
- [x] **Session Management** ✅
  - [x] ذخیره JWT در httpOnly cookie یا sessionStorage ✅
  - [x] مدیریت انقضای token ✅
  - [x] تمدید خودکار token با refreshToken ✅
  - [x] ریدایرکت به صفحه ورود در صورت انقضا ✅
- [x] **Auth Guard** ✅
  - [x] Middleware برای محافظت از صفحات ✅
  - [x] بررسی وضعیت احراز هویت ✅
  - [x] ریدایرکت خودکار ✅
- [x] **Logout** ✅
  - [x] صفحه/دکمه خروج ✅
  - [x] پاک کردن token و refreshToken ✅
  - [x] ریدایرکت به صفحه ورود ✅

### تست — احراز هویت
- [ ] **Unit Tests**
  - [ ] تست jwt.ts (issue, verify)
  - [ ] تست otp.service (request, verify)
  - [ ] تست phone.ts (normalize)
- [ ] **Integration Tests**
  - [ ] POST /api/auth/otp/request
  - [ ] POST /api/auth/otp/verify
  - [ ] POST /api/auth/refresh
  - [ ] POST /api/auth/logout
  - [ ] تست محافظت از routes با JWT
- [ ] **E2E Tests**
  - [ ] سناریو ورود کامل (درخواست OTP → تایید → ورود)
  - [ ] سناریو تمدید token
  - [ ] سناریو خروج
- [x] **Manual Testing** ✅
  - [x] تست UI ورود در موبایل و دسکتاپ ✅
  - [x] تست RTL ✅
  - [ ] تست Accessibility

### Postman — آماده‌سازی Flutter
- [x] **Postman Collection برای Auth** ✅
  - [x] Request OTP ✅
  - [x] Verify OTP ✅
  - [x] Refresh Token ✅ (API آماده، تست دستی لازم)
  - [x] Logout ✅ (API آماده، تست دستی لازم)
  - [x] Test Scripts (ذخیره خودکار token) ✅
- [x] **API Response Standardization** ✅
  - [x] ساختار یکپارچه: `{success, data, message, errors}` ✅
  - [x] Token Expiry در Response: `expiresIn`, `refreshExpiresIn` ✅

---

## فاز 6 — ماژول‌های اصلی (همزمان بک‌اند و فرانت‌اند)

### ماژول 1: Customers (اولویت بالا)

#### بک‌اند
- [x] Service: CRUD، فیلتر/جستجو، تخصیص بازاریاب ✅
- [x] API Endpoints: GET, POST, PATCH, DELETE ✅
- [x] محافظت از API با Authentication Middleware ✅
- [x] استفاده از Error Handler مرکزی ✅
- [x] پشتیبانی از Pagination در Service و API ✅
- [x] فیلتر شهر در Service و API ✅
- [ ] **ایندکس‌های MongoDB**
  - [ ] ایندکس برای `contact.phone` (جستجوی سریع)
  - [ ] ایندکس برای `displayName` (text search)
  - [ ] ایندکس برای `status` و `assignedMarketerId`
- [ ] **Import از Excel**
  - [ ] API: POST /api/customers/import
  - [ ] Parser برای فایل Excel
  - [ ] Validation و error handling
- [ ] **Export به Excel**
  - [ ] API: GET /api/customers/export
  - [ ] Generator برای Excel

#### فرانت‌اند
- [x] صفحه Customers با داده واقعی ✅
- [x] فرم ایجاد مشتری ✅
- [x] **فرم ویرایش مشتری** ✅
  - [x] Modal یا صفحه جداگانه ✅
  - [x] Pre-fill داده‌های موجود ✅
  - [x] Validation ✅
- [ ] **Import از Excel**
  - [ ] دکمه Import
  - [ ] آپلود فایل
  - [ ] نمایش پیش‌نمایش داده
  - [ ] تایید و ثبت
- [ ] **Export به Excel**
  - [ ] دکمه Export
  - [ ] دانلود فایل
- [x] **فیلتر پیشرفته** ✅
  - [x] فیلتر بر اساس وضعیت ✅
  - [x] فیلتر بر اساس شهر ✅
  - [x] فیلتر بر اساس بازاریاب ✅
  - [x] جستجوی زنده ✅
- [x] **Pagination** ✅
  - [x] صفحه‌بندی لیست ✅
  - [x] انتخاب تعداد آیتم در صفحه ✅ (20 آیتم پیش‌فرض)
- [ ] **جزئیات مشتری**
  - [ ] Modal یا صفحه جداگانه
  - [ ] نمایش اطلاعات کامل
  - [ ] تاریخچه تعاملات

#### تست
- [ ] **Unit Tests**: customers.service
- [ ] **Integration Tests**: تمام endpoints Customers
- [ ] **E2E Tests**: سناریو ایجاد/ویرایش/حذف مشتری
- [x] **Manual Testing**: UI لیست، فرم، Pagination ✅
  - [x] تست ایجاد مشتری از UI ✅
  - [x] تست فیلترها در UI ✅
  - [x] تست Pagination در UI ✅
  - [x] تست حذف مشتری از UI ✅
  - [ ] تست ویرایش مشتری (بعد از پیاده‌سازی)
  - [ ] تست Import/Export Excel (بعد از پیاده‌سازی)

---

### ماژول 2: Visits (اولویت بالا)

#### بک‌اند
- [x] Service: Overview Service ✅
- [x] **Service کامل** ✅
  - [x] createVisit() ✅
  - [x] updateVisit() ✅
  - [x] deleteVisit() ✅
  - [x] changeVisitStatus() ✅
  - [x] listVisits() با فیلتر (تاریخ، بازاریاب، مشتری، وضعیت) ✅
- [x] **API Endpoints** ✅
  - [x] GET /api/visits (لیست با فیلتر و pagination) ✅
  - [x] POST /api/visits (ایجاد ویزیت) ✅
  - [x] GET /api/visits/[id] (جزئیات) ✅
  - [x] PATCH /api/visits/[id] (ویرایش) ✅
  - [x] DELETE /api/visits/[id] (حذف) ✅
  - [x] PATCH /api/visits/[id]/status (تغییر وضعیت) ✅
- [ ] **ایندکس‌های MongoDB**
  - [ ] ایندکس برای `customerId`
  - [ ] ایندکس برای `marketerId`
  - [ ] ایندکس برای `scheduledAt` (جستجوی سریع بر اساس تاریخ)
  - [ ] ایندکس برای `status`

#### فرانت‌اند
- [x] **اتصال به داده واقعی** ✅
  - [x] لیست ویزیت‌ها با داده واقعی ✅
  - [x] فیلتر بر اساس تاریخ ✅
  - [x] فیلتر بر اساس بازاریاب ✅
  - [x] فیلتر بر اساس وضعیت ✅
- [x] **فرم ثبت/ویرایش ویزیت** ✅
  - [x] انتخاب مشتری (Searchable Select) ✅
  - [x] انتخاب بازاریاب (Searchable Select) ✅
  - [x] انتخاب تاریخ و ساعت (تاریخ شمسی) ✅
  - [x] ثبت یادداشت ✅
  - [x] ثبت موضوعات و اقدام پیگیری ✅
  - [x] بهبود استایل Modal (اندازه مناسب، padding، scroll) ✅
  - [ ] ثبت مختصات (اختیاری - برای فاز بعدی)
- [ ] **نقشه تعاملی با API نشان** 🗺️
  - [ ] افزودن API Key نشان به `.env.example` (NESHAN_API_KEY=web.eaba70d1a1b34fb2a2ad25306e8e58c7)
  - [ ] نصب کتابخانه نقشه نشان (neshan-maps-gl یا neshan-web-sdk)
  - [ ] ایجاد کامپوننت `NeshanMap` در `components/visits/neshan-map.tsx`
  - [ ] نمایش نقشه در صفحه Visits با API Key
  - [ ] نمایش موقعیت ویزیت‌ها روی نقشه (Marker)
  - [ ] امکان انتخاب موقعیت برای ویزیت جدید (Click on map)
  - [ ] ذخیره مختصات (latitude, longitude) در Visit
  - [ ] نمایش مسیر بین ویزیت‌ها (اختیاری)
  - [ ] RTL Support برای نقشه
- [ ] **تغییر وضعیت ویزیت**
  - [ ] دکمه تغییر وضعیت
  - [ ] Confirmation dialog
  - [ ] به‌روزرسانی خودکار UI

#### تست
- [ ] **Unit Tests**: visits.service
- [ ] **Integration Tests**: تمام endpoints Visits
- [ ] **E2E Tests**: سناریو ثبت ویزیت
- [ ] **Manual Testing**: UI نقشه و جدول

---

### ماژول 3: Invoices (اولویت بالا) — 90% تکمیل ✅

#### بک‌اند
- [x] **Service کامل** ✅
  - [x] createInvoice() ✅
  - [x] updateInvoice() ✅
  - [x] calculateInvoiceTotal() (محاسبه خودکار جمع کل) ✅
  - [x] markAsPaid() ✅
  - [x] listInvoices() با فیلتر ✅
  - [x] getInvoiceById() با جزئیات کامل مشتری ✅
- [x] **API Endpoints** ✅
  - [x] GET /api/invoices (لیست با فیلتر و pagination) ✅
  - [x] POST /api/invoices (ایجاد پیش‌فاکتور) ✅
  - [x] GET /api/invoices/[id] (جزئیات) ✅
  - [x] PATCH /api/invoices/[id] (ویرایش) ✅
  - [x] DELETE /api/invoices/[id] (حذف) ✅
  - [x] PATCH /api/invoices/[id]/status (تغییر وضعیت پرداخت) ✅
  - [x] GET /api/invoices/[id]/pdf (دانلود PDF) ✅
- [x] **PDF Generation** ✅
  - [x] نصب کتابخانه (pdfkit) ✅
  - [x] Template پیش‌فاکتور ✅
  - [x] تولید PDF با داده واقعی ✅
  - [x] استفاده از فونت‌های استاندارد PDF (Times-Roman, Times-Bold) ✅
  - [x] رفع مشکل فونت‌ها در production ✅
- [ ] **ایندکس‌های MongoDB**
  - [ ] ایندکس برای `customerId`
  - [ ] ایندکس برای `status`
  - [ ] ایندکس برای `dueAt` (جستجوی پیش‌فاکتورهای معوق)

#### فرانت‌اند
- [x] **اتصال به داده واقعی** ✅
  - [x] لیست پیش‌فاکتورها با داده واقعی ✅
  - [x] فیلتر بر اساس وضعیت ✅
  - [x] فیلتر بر اساس تاریخ ✅
  - [x] Pagination ✅
- [x] **فرم ایجاد/ویرایش پیش‌فاکتور** ✅
  - [x] انتخاب مشتری ✅
  - [x] افزودن آیتم‌ها (محصول، تعداد، قیمت) ✅
  - [x] محاسبه خودکار جمع کل ✅
  - [x] انتخاب تاریخ سررسید (PersianDateTimePicker) ✅
  - [x] ثبت یادداشت ✅
- [x] **پیش‌نمایش PDF** ✅
  - [x] صفحه جزئیات پیش‌فاکتور ✅
  - [x] دکمه دانلود PDF ✅
  - [x] باز کردن PDF در تب جدید ✅
  - [x] نمایش جزئیات کامل مشتری در صفحه جزئیات ✅
- [ ] **تغییر وضعیت پرداخت**
  - [ ] دکمه تغییر وضعیت در صفحه جزئیات
  - [ ] Confirmation dialog
  - [ ] به‌روزرسانی خودکار UI

#### تست
- [ ] **Unit Tests**: invoices.service, PDF generation
- [ ] **Integration Tests**: تمام endpoints Invoices
- [ ] **E2E Tests**: سناریو ایجاد و دانلود PDF
- [ ] **Manual Testing**: UI پیش‌نمایش PDF

---

### ماژول 4: Marketers (اولویت متوسط)

#### بک‌اند
- [x] **Service کامل** ✅
  - [x] createMarketer() ✅
  - [x] updateMarketer() ✅
  - [ ] assignRole()
  - [ ] toggleActiveStatus()
  - [ ] getPerformanceStats()
  - [x] listMarketers() با فیلتر و Pagination ✅
- [x] **API Endpoints** ✅
  - [x] GET /api/marketers (لیست با فیلتر و Pagination) ✅
  - [x] POST /api/marketers (ایجاد بازاریاب) ✅
  - [x] GET /api/marketers/[id] (جزئیات) ✅
  - [x] PATCH /api/marketers/[id] (ویرایش) ✅
  - [x] DELETE /api/marketers/[id] (حذف) ✅
  - [ ] GET /api/marketers/[id]/performance (آمار عملکرد)

#### فرانت‌اند
- [x] **اتصال به داده واقعی** ✅
  - [x] لیست بازاریاب‌ها با داده واقعی ✅
  - [x] کارت‌های عملکرد ✅
  - [x] Pagination (حداکثر 8 کارت در هر صفحه - 2 ردیف) ✅
  - [x] Sort بر اساس تاریخ ایجاد (جدیدترین اول) ✅
  - [ ] فیلتر بر اساس منطقه
- [x] **فرم ایجاد/ویرایش بازاریاب** ✅
  - [x] ثبت اطلاعات شخصی ✅
  - [x] انتخاب نقش ✅
  - [x] تعیین منطقه ✅
  - [x] فعال/غیرفعال کردن حساب ✅
  - [x] دکمه ویرایش در کارت ✅
  - [x] دکمه حذف در کارت ✅
- [x] **تابلوی امتیاز داینامیک** ✅
  - [x] نمایش 4 بازاریاب برتر بر اساس امتیاز ✅
  - [x] به‌روزرسانی خودکار ✅
- [ ] **مدیریت نقش و دسترسی**
  - [ ] نمایش نقش فعلی
  - [ ] تغییر نقش
  - [ ] نمایش دسترسی‌ها
- [ ] **نمودار عملکرد**
  - [ ] نمودار ویزیت‌ها
  - [ ] نمودار نرخ تبدیل
  - [ ] نمودار درآمد

#### تست
- [ ] **Unit Tests**: marketers.service
- [ ] **Integration Tests**: تمام endpoints Marketers
- [ ] **E2E Tests**: سناریو ایجاد بازاریاب
- [ ] **Manual Testing**: UI مدیریت نقش

---

### ماژول 5: SMS Center (اولویت متوسط)

#### بک‌اند
- [ ] **Service کامل**
  - [ ] sendCampaignSms()
  - [ ] listSmsLogs()
  - [ ] getSmsStatus()
  - [ ] createCampaign()
- [ ] **API Endpoints**
  - [ ] GET /api/sms/campaigns (لیست کمپین‌ها)
  - [ ] POST /api/sms/campaigns (ایجاد کمپین)
  - [ ] GET /api/sms/logs (لاگ ارسال‌ها)
  - [ ] POST /api/sms/send (ارسال فوری)

#### فرانت‌اند
- [x] **UI پایه** ✅
  - [x] صفحه SMS Center با کارت‌های آمار ✅
  - [x] لیست کمپین‌های اخیر ✅
  - [x] دکمه "ایجاد کمپین جدید" با Toast notification ✅
- [ ] **اتصال به داده واقعی**
  - [ ] لیست کمپین‌ها از API
  - [ ] آمار ارسال‌ها از API
  - [ ] وضعیت تحویل از API
- [ ] **فرم ایجاد کمپین**
  - [ ] Modal برای ایجاد کمپین
  - [ ] انتخاب مخاطبین (مشتریان، بازاریاب‌ها)
  - [ ] نوشتن متن پیام
  - [ ] زمان‌بندی ارسال
  - [ ] پیش‌نمایش پیام

#### تست
- [ ] **Unit Tests**: sms service
- [ ] **Integration Tests**: تمام endpoints SMS
- [ ] **Manual Testing**: UI کمپین‌ها

---

### ماژول 6: Reports (اولویت متوسط)

#### بک‌اند
- [x] Service: Dashboard Overview ✅
- [ ] **Service کامل**
  - [ ] getCustomerReports()
  - [ ] getInvoiceReports()
  - [ ] getVisitReports()
  - [ ] exportToExcel()
- [ ] **API Endpoints**
  - [ ] GET /api/reports/dashboard (KPI داشبورد)
  - [ ] GET /api/reports/customers (گزارش مشتریان)
  - [ ] GET /api/reports/invoices (گزارش پیش‌فاکتورها)
  - [ ] GET /api/reports/visits (گزارش ویزیت‌ها)
  - [ ] GET /api/reports/export (خروجی Excel)

#### فرانت‌اند
- [ ] **اتصال به داده واقعی**
  - [ ] نمودارهای تحلیلی
  - [ ] جداول گزارش
  - [ ] فیلترهای پیشرفته
- [ ] **خروجی Excel/PDF**
  - [ ] دکمه Export
  - [ ] انتخاب فرمت
  - [ ] دانلود فایل

#### تست
- [ ] **Unit Tests**: reports service
- [ ] **Integration Tests**: تمام endpoints Reports
- [ ] **Manual Testing**: UI گزارش‌ها

---

### ماژول 7: Settings (اولویت متوسط)

#### بک‌اند
- [ ] **API Endpoints**
  - [ ] GET /api/settings/roles (لیست نقش‌ها)
  - [ ] POST /api/settings/roles (ایجاد نقش)
  - [ ] PATCH /api/settings/roles/[id] (ویرایش نقش)
  - [ ] GET /api/settings/integrations (لیست یکپارچگی‌ها)
  - [ ] PATCH /api/settings/integrations/[id] (به‌روزرسانی یکپارچگی)

#### فرانت‌اند
- [ ] **اتصال به داده واقعی**
  - [ ] مدیریت نقش‌ها (CRUD)
  - [ ] تنظیمات اعلان‌ها (فعال/غیرفعال)
  - [ ] مدیریت یکپارچگی‌ها
  - [ ] تغییرات ظاهر سیستم

#### تست
- [ ] **Integration Tests**: تمام endpoints Settings
- [ ] **Manual Testing**: UI تنظیمات

---

## فاز 7 — کتابخانه کامپوننت‌های قابل استفاده مجدد

### کامپوننت‌های پایه
- [ ] **Button**
  - [ ] انواع: primary, secondary, danger, ghost
  - [ ] اندازه‌ها: sm, md, lg
  - [ ] حالت‌ها: loading, disabled
  - [ ] RTL support
- [ ] **Input**
  - [ ] انواع: text, number, tel, email
  - [ ] Validation و error states
  - [ ] Label و helper text
  - [ ] RTL support
- [ ] **Card**
  - [ ] Header, Body, Footer
  - [ ] انواع: default, bordered, shadow
- [ ] **Table**
  - [ ] Header, Body, Footer
  - [ ] Pagination
  - [ ] Sorting
  - [ ] Responsive (تبدیل به Card در موبایل)
- [x] **Modal/Dialog** ✅
  - [x] باز/بسته شدن ✅
  - [x] Backdrop ✅
  - [x] Animation ✅
  - [x] اندازه مناسب (max-w-3xl) ✅
  - [x] Scroll برای محتوای طولانی ✅
  - [ ] Accessibility (ARIA labels)
- [ ] **Tabs**
  - [ ] Tab navigation
  - [ ] Content switching
- [x] **Select/Dropdown** ✅
  - [x] Single select (SearchableSelect) ✅
  - [x] Search functionality ✅
  - [x] Dropdown با فیلتر زنده ✅
  - [x] Click outside to close ✅
  - [ ] Multi select
- [ ] **Badge/Status**
  - [ ] انواع رنگ‌ها
  - [ ] اندازه‌ها
- [ ] **Loading Spinner/Skeleton**
  - [ ] Spinner برای دکمه‌ها
  - [ ] Skeleton برای لیست‌ها
- [ ] **Toast/Notification**
  - [ ] Success, Error, Warning, Info
  - [ ] Auto dismiss
  - [ ] Manual dismiss
- [x] **Persian Date Picker** ✅
  - [x] ورودی تاریخ شمسی ✅
  - [x] ورودی ساعت جداگانه ✅
  - [x] تبدیل خودکار به میلادی ✅
  - [x] مقدار پیش‌فرض (فردا) ✅
- [x] **Pagination** ✅
  - [x] دکمه‌های قبلی/بعدی ✅
  - [x] نمایش شماره صفحه ✅
  - [x] نمایش تعداد کل ✅
  - [x] URL-based navigation ✅

---

## فاز 8 — بهینه‌سازی و تکمیل

### بهینه‌سازی عملکرد
- [ ] **Image Optimization**
  - [ ] استفاده از next/image
  - [ ] Lazy loading
- [ ] **Code Splitting**
  - [ ] Lazy loading برای صفحات
  - [ ] Dynamic imports
- [ ] **API Caching**
  - [ ] استفاده از React Query یا SWR
  - [ ] Cache invalidation
- [ ] **Bundle Size**
  - [ ] بررسی bundle size
  - [ ] بهینه‌سازی imports
  - [ ] Tree shaking

### بهینه‌سازی دیتابیس
- [ ] **ایندکس‌ها**
  - [ ] بررسی و بهینه‌سازی ایندکس‌های موجود
  - [ ] افزودن ایندکس‌های جدید بر اساس نیاز
- [ ] **Query Optimization**
  - [ ] بهینه‌سازی query‌های کند
  - [ ] استفاده از aggregation pipeline
- [ ] **Migration Scripts**
  - [ ] اسکریپت‌های migration برای تغییرات ساختاری

### Seed Data
- [ ] **Seed Scripts**
  - [ ] Seed برای Customers
  - [ ] Seed برای Marketers
  - [ ] Seed برای Visits
  - [ ] Seed برای Invoices
  - [ ] Seed برای SMSLogs

---

## فاز 9 — تست‌های جامع

### Unit Tests
- [ ] راه‌اندازی Vitest یا Jest
- [ ] تست Services (70-80% coverage)
- [ ] تست Utilities (90%+ coverage)
- [ ] تست Validators (Zod schemas)

### Integration Tests
- [ ] راه‌اندازی Supertest
- [ ] تست API Endpoints (80%+ coverage)
- [ ] تست Database Operations
- [ ] تست Authentication Flow
- [ ] تست Error Handling

### E2E Tests
- [ ] راه‌اندازی Playwright یا Cypress
- [ ] سناریو ورود کامل
- [ ] سناریو ایجاد مشتری
- [ ] سناریو ثبت ویزیت
- [ ] سناریو ایجاد پیش‌فاکتور
- [ ] سناریو مدیریت نقش

### Manual Testing
- [ ] تست در Chrome, Firefox, Safari (Desktop)
- [ ] تست در Chrome Mobile, Safari Mobile
- [ ] تست در Tablet (iPad)
- [ ] تست RTL در همه مرورگرها
- [ ] تست Keyboard Navigation
- [ ] تست Screen Reader (Accessibility)

---

## فاز 10 — آماده‌سازی Flutter/Android

### Postman Collection کامل
- [ ] **Auth Collection**
  - [x] Request OTP ✅
  - [x] Verify OTP ✅
  - [x] Refresh Token ✅ (API آماده است)
  - [x] Logout ✅ (API آماده است)
- [ ] **Customers Collection**
  - [x] List, Get, Create, Update, Delete ✅
  - [ ] Import, Export
- [ ] **Visits Collection**
  - [x] List, Get, Create, Update, Delete ✅
  - [x] Change Status ✅
  - [ ] Get Locations (برای نقشه)
  - [ ] Update Location
- [ ] **Invoices Collection**
  - [ ] List, Get, Create, Update, Delete
  - [ ] Get PDF
- [ ] **Marketers Collection**
  - [ ] List, Get, Create, Update, Delete
  - [ ] Get Performance
- [ ] **SMS Collection**
  - [ ] List Campaigns, Create Campaign
  - [ ] List Logs, Send SMS
- [ ] **Reports Collection**
  - [ ] Dashboard, Customers, Invoices, Visits
  - [ ] Export

### Postman Environment
- [ ] متغیرهای baseUrl, authToken, refreshToken, testPhone
- [ ] Pre-request Scripts (ذخیره خودکار token)
- [ ] Test Scripts (validation responses)

### API Documentation
- [ ] Markdown Documentation برای تمام endpoints
- [ ] Response Examples (Success + Error)
- [ ] Error Codes Standard

---

## فاز 11 — استقرار و تحویل

- [ ] ساخت Build نهایی (`next build`)
- [ ] استقرار روی سی‌پنل با `node server.js` و پورت 3124
- [ ] اتصال دامنه `https://tamirban1.ir/` به برنامه Node.js
- [ ] تنظیم و تست SSL روی دامنه
- [ ] قرار دادن `.env` نهایی روی سرور
- [ ] تست نهایی روی محیط واقعی
- [ ] تحویل Postman Collection و Environment به تیم اندروید
- [ ] توافق بر برنامه پشتیبانی

---

## 🎯 استراتژی جامع توسعه — نگاه کلی به پروژه

این بخش شامل استراتژی کلی، آماده‌سازی Flutter، تست همزمان و UX است. جزئیات کامل در `docs/flutter-preparation.md` و `docs/testing-strategy.md` موجود است.

### ✅ تایید احراز هویت
- [x] **JWT**: استفاده از `jsonwebtoken` برای صدور و بررسی توکن ✅
- [x] **bcrypt**: استفاده از `bcryptjs` برای hash کردن OTP ✅
- [x] **جریان احراز هویت**: درخواست OTP → Hash با bcrypt → تایید → صدور JWT ✅

### 📊 برآورد زمانی تفصیلی

| فاز | بک‌اند | فرانت‌اند | تست | Flutter Prep | جمع |
|------|-------|----------|-----|--------------|-----|
| فاز 5.5: زیرساخت | 2-3 روز | 1-2 روز | 1-2 روز | 1 روز | 5-8 روز |
| فاز 6.1: Customers | 1-2 روز | 2-3 روز | 1-2 روز | 0.5 روز | 4.5-7.5 روز |
| فاز 6.2: Visits | 2-3 روز | 2-3 روز | 1-2 روز | 0.5 روز | 5.5-8.5 روز |
| فاز 6.3: Invoices | 3-4 روز | 2-3 روز | 1-2 روز | 0.5 روز | 6.5-9.5 روز |
| فاز 6.4: Marketers | 2-3 روز | 1-2 روز | 1 روز | 0.5 روز | 4.5-6.5 روز |
| فاز 6.5: SMS | 2 روز | 1 روز | 0.5 روز | 0.5 روز | 4 روز |
| فاز 6.6: Reports | 2-3 روز | 1-2 روز | 1 روز | 0.5 روز | 4.5-6.5 روز |
| فاز 6.7: Settings | 1-2 روز | 1-2 روز | 0.5 روز | - | 2.5-4.5 روز |
| فاز 7: Components | - | 2-3 روز | 1 روز | - | 3-4 روز |
| فاز 8: بهینه‌سازی | 1-2 روز | 1-2 روز | 1 روز | - | 3-5 روز |
| فاز 9: تست جامع | - | - | 2-3 روز | - | 2-3 روز |
| فاز 10: Flutter Prep | - | - | - | 2-3 روز | 2-3 روز |
| **جمع کل** | **18-26 روز** | **14-20 روز** | **11-16 روز** | **5-7 روز** | **48-69 روز** |

> توجه: این زمان‌ها برای یک توسعه‌دهنده است. با تیم 2-3 نفره می‌توان به 5-6 هفته کاهش داد.

### 📱 آماده‌سازی زیرساخت برای Flutter/Android (از الان شروع شود)

#### فوری (قبل از شروع Flutter):
- [ ] **API Response Standardization**: ساختار یکپارچه پاسخ‌ها (`{success, data, message, errors}`)
- [ ] **Error Handling Standard**: کدهای خطای استاندارد و فرمت یکپارچه
- [ ] **Postman Collection کامل**: تمام endpoints با مثال درخواست/پاسخ
  - [ ] Auth (Request OTP, Verify OTP, Refresh Token, Logout)
  - [ ] Customers (CRUD کامل)
  - [ ] Visits (CRUD کامل)
  - [ ] Invoices (CRUD + PDF)
  - [ ] Marketers (CRUD کامل)
  - [ ] SMS (Campaigns, Logs)
  - [ ] Reports (Dashboard, Analytics)
- [ ] **Postman Environment**: متغیرهای baseUrl، authToken، refreshToken، testPhone
- [ ] **Postman Test Scripts**: خودکار کردن تست‌ها و ذخیره token
- [ ] **CORS Configuration**: امکان تست از Flutter WebView یا Browser
- [ ] **Refresh Token API**: POST /api/auth/refresh برای مدیریت session موبایل
- [ ] **Token Expiry در Response**: `expiresIn` و `refreshExpiresIn` برای مدیریت خودکار

#### متوسط (همزمان با توسعه):
- [ ] **API Documentation**: Markdown یا Swagger برای تمام endpoints
- [ ] **Pagination Standard**: Query params و Response format یکپارچه (`?page=1&limit=20`)
- [ ] **Response Examples**: مثال‌های موفقیت و خطا برای هر endpoint

#### پایین (بعد از MVP):
- [ ] **File Upload/Download API**: اگر نیاز باشد
- [ ] **WebSocket/Real-time**: اگر نیاز باشد

> 📖 جزئیات کامل در `docs/flutter-preparation.md`

---

### 🧪 استراتژی تست همزمان با توسعه

#### فلسفه: Test-Driven Development (TDD) سبک
- ✅ تست‌ها **همزمان با کد** نوشته می‌شوند نه بعد از آن
- ✅ **اولویت بر Integration Tests** (API + UI)
- ✅ **E2E Tests برای سناریوهای کلیدی**

#### سطوح تست:

**1. Unit Tests (اولویت متوسط)**
- [ ] راه‌اندازی Vitest یا Jest
- [ ] تست Services (customers.service, visits.service, ...)
- [ ] تست Utilities (jwt, phone, otp)
- [ ] تست Validators (Zod schemas)
- Coverage هدف: Services 70-80%, Utilities 90%+

**2. Integration Tests (اولویت بالا)** ⚠️
- [ ] راه‌اندازی Supertest برای API testing
- [ ] تست API Endpoints (Request → Response)
- [ ] تست Database Operations (CRUD)
- [ ] تست Authentication Flow
- [ ] تست Error Handling
- Coverage هدف: API Endpoints 80%+

**3. E2E Tests (اولویت بالا برای سناریوهای کلیدی)** 🎯
- [ ] راه‌اندازی Playwright یا Cypress
- [ ] سناریو ورود کامل (درخواست OTP → تایید → ورود)
- [ ] سناریو ایجاد مشتری (ورود → ایجاد → مشاهده)
- [ ] سناریو ثبت ویزیت (انتخاب مشتری → ثبت → مشاهده)
- [ ] سناریو ایجاد پیش‌فاکتور (ایجاد → دانلود PDF)
- [ ] سناریو مدیریت نقش (ورود مدیر → ایجاد بازاریاب)

**4. Manual Testing (همیشه)** 👤
- [ ] تست در Chrome, Firefox, Safari (Desktop)
- [ ] تست در Chrome Mobile, Safari Mobile
- [ ] تست در Tablet (iPad)
- [ ] تست RTL در همه مرورگرها
- [ ] تست Keyboard Navigation
- [ ] تست Screen Reader (Accessibility)

> 📖 جزئیات کامل و تست‌های مرحله‌ای در `docs/testing-strategy.md`

#### تست‌های مرحله‌ای برای هر ماژول:

**فاز 1: احراز هویت**
- [ ] Unit: otp.service, jwt.ts, phone.ts
- [ ] Integration: POST /api/auth/otp/request, POST /api/auth/otp/verify
- [ ] E2E: سناریو ورود کامل
- [ ] Manual: UI ورود در موبایل و دسکتاپ

**فاز 2: Customers**
- [ ] Unit: customers.service (CRUD)
- [ ] Integration: تمام endpoints Customers
- [ ] E2E: سناریو ایجاد/ویرایش/حذف مشتری
- [ ] Manual: UI لیست، فرم، Pagination

**فاز 3: Visits**
- [ ] Unit: visits.service
- [ ] Integration: تمام endpoints Visits
- [ ] E2E: سناریو ثبت ویزیت
- [ ] Manual: UI نقشه و جدول

**فاز 4: Invoices**
- [ ] Unit: invoices.service, PDF generation
- [ ] Integration: تمام endpoints Invoices
- [ ] E2E: سناریو ایجاد و دانلود PDF
- [ ] Manual: UI پیش‌نمایش PDF

---

### 🎨 نکات UX و تجربه کاربری

#### اصول کلی:
- [ ] **Loading States**: همه عملیات async باید loading state داشته باشند
- [ ] **Error Messages**: پیام‌های خطا واضح و کاربرپسند (فارسی)
- [ ] **Success Feedback**: Toast یا Notification برای عملیات موفق
- [ ] **Confirmation Dialogs**: برای عملیات حساس (حذف، تغییر وضعیت)
- [ ] **Optimistic Updates**: به‌روزرسانی UI قبل از پاسخ سرور (جایی که ممکن است)
- [ ] **Skeleton Loaders**: به جای spinner برای لیست‌ها
- [ ] **Empty States**: پیام مناسب وقتی داده‌ای وجود ندارد
- [ ] **Form Validation**: اعتبارسنجی real-time در فرم‌ها
- [ ] **Keyboard Shortcuts**: برای عملیات پرتکرار (اختیاری)

#### Responsive Design:
- [ ] **Mobile First**: طراحی اول برای موبایل
- [ ] **Breakpoints**: sm (640px), md (768px), lg (1024px), xl (1280px)
- [ ] **Touch Targets**: حداقل 44x44px برای دکمه‌ها در موبایل
- [ ] **Sidebar**: تبدیل به Drawer در موبایل
- [ ] **Tables**: تبدیل به Card در موبایل (یا horizontal scroll)

#### RTL Support:
- [ ] **Text Direction**: همه متن‌ها RTL
- [ ] **Icons**: آیکون‌ها در جهت صحیح
- [ ] **Numbers**: اعداد در جهت صحیح (LTR)
- [ ] **Inputs**: placeholder و value در جهت صحیح

#### Accessibility:
- [ ] **ARIA Labels**: برای عناصر تعاملی
- [ ] **Keyboard Navigation**: Tab, Enter, Escape
- [ ] **Focus States**: واضح و قابل مشاهده
- [ ] **Color Contrast**: حداقل 4.5:1 برای متن
- [ ] **Screen Reader**: تست با ChromeVox یا NVDA

#### Performance:
- [ ] **Image Optimization**: استفاده از next/image
- [ ] **Code Splitting**: Lazy loading برای صفحات
- [ ] **API Caching**: استفاده از React Query یا SWR
- [ ] **Bundle Size**: بررسی و بهینه‌سازی

---

### 📋 روند کار کلی (Workflow)

#### مرحله 1: زیرساخت (هفته 1)
1. **بک‌اند**: Auth Middleware + RBAC
2. **فرانت‌اند**: Session Management + کامپوننت‌های پایه
3. **تست**: Unit + Integration برای Auth
4. **Postman**: Collection کامل برای Auth
5. **UX**: تایید UI احراز هویت

#### مرحله 2: ماژول‌های اصلی (هفته 2-3)
برای هر ماژول (Visits, Invoices):
1. **بک‌اند**: Service + API Endpoints
2. **فرانت‌اند**: اتصال UI به API
3. **تست**: Unit + Integration + E2E
4. **Postman**: به‌روزرسانی Collection
5. **UX**: تایید UI و تجربه کاربری
6. **Manual Testing**: تست در مرورگرهای مختلف

#### مرحله 3: ماژول‌های تکمیلی (هفته 4)
1. **Marketers**: Service + API + UI
2. **SMS**: Service + API + UI
3. **Reports**: Service + API + UI
4. **تست**: Integration + Manual

#### مرحله 4: تکمیل (هفته 5)
1. **PDF Generation**: پیاده‌سازی و تست
2. **Excel Import/Export**: پیاده‌سازی و تست
3. **Performance Testing**: بهینه‌سازی
4. **Security Testing**: بررسی امنیتی
5. **Documentation**: به‌روزرسانی مستندات
6. **Flutter Handoff**: آماده‌سازی برای تیم Flutter

---

### ✅ چک‌لیست تحویل هر ماژول

قبل از تحویل هر ماژول، این موارد باید کامل باشند:

**بک‌اند:**
- [ ] Service کامل با Validation
- [ ] API Endpoints با Authentication
- [ ] Error Handling مناسب
- [ ] Unit Tests (70%+ coverage)
- [ ] Integration Tests (80%+ coverage)

**فرانت‌اند:**
- [ ] UI کامل و Responsive
- [ ] Loading و Error States
- [ ] Form Validation
- [ ] RTL Support
- [ ] Manual Testing انجام شده

**تست:**
- [ ] E2E Test برای سناریوی کلیدی
- [ ] Manual Testing در مرورگرهای مختلف
- [ ] Performance قابل قبول

**مستندات:**
- [ ] Postman Collection به‌روز شده
- [ ] API Documentation به‌روز شده
- [ ] README به‌روز شده

---

### 📊 برآورد زمانی کلی

| فاز | زمان | توضیح |
|------|------|-------|
| زیرساخت | 1 هفته | Auth + Middleware + Session |
| ماژول‌های اصلی | 2-3 هفته | Visits + Invoices |
| ماژول‌های تکمیلی | 1 هفته | Marketers + SMS + Reports |
| تکمیل | 1 هفته | PDF + Excel + Testing |
| **جمع** | **5-6 هفته** | برای MVP کامل |

> توجه: این زمان شامل تست‌های همزمان است. تست‌ها ~70% زمان توسعه را می‌گیرند اما باعث کاهش باگ‌ها و صرفه‌جویی در زمان می‌شوند.

---

## 🔧 رفع مشکلات UI و UX (اولویت فوری)

### مشکل 1: بهبود متن کارت "میانگین نرخ تبدیل تیم"
- [x] بهبود متن کارت در `components/marketers/marketer-page-client.tsx` ✅
  - [x] تغییر "میانگین نرخ تبدیل تیم" به متن واضح‌تر ✅
  - [x] بهبود نمایش درصد و تغییرات ✅

### مشکل 2: حذف دکمه تکراری "افزودن مشتری جدید"
- [x] بررسی صفحه `/dashboard/customers` ✅
- [x] حذف یکی از دکمه‌های "افزودن مشتری جدید" یا "ثبت سریع مشتری جدید" ✅
- [x] یکپارچه‌سازی فرم ایجاد مشتری در یک مکان ✅

### مشکل 3: بهبود فرمت نمایش ارورها
- [ ] بررسی `app/dashboard/customers/actions.ts` و `app/dashboard/marketers/actions.ts`
- [ ] تبدیل ارورهای Zod به پیام‌های کاربرپسند فارسی
- [ ] نمایش ارورها به صورت لیست (اگر چند ارور وجود دارد)
- [ ] بهبود نمایش ارور در `components/customers/customer-create-form.tsx`
- [ ] بهبود نمایش ارور در `components/marketers/marketer-edit-modal.tsx`
- [ ] تبدیل ارورهای MongoDB به پیام‌های قابل فهم

### مشکل 4: رفع ارور "Update document requires atomic operators"
- [x] بررسی `lib/services/marketers.service.ts` در تابع `updateMarketer` ✅
- [x] بررسی `lib/db/repositories/base.repository.ts` برای متد `updateById` ✅
- [x] اطمینان از استفاده صحیح از `$set` در MongoDB update operations ✅
- [x] تست ویرایش بازاریاب و بررسی رفع ارور ✅

### مشکل 5: محدودسازی دسترسی ادمین اصلی
- [ ] بررسی نقش `SUPER_ADMIN` در `lib/middleware/rbac.ts`
- [ ] تعریف محدودیت‌های دسترسی برای ادمین اصلی
- [ ] جلوگیری از تغییر نقش خود ادمین اصلی
- [ ] جلوگیری از غیرفعال کردن حساب خود ادمین اصلی
- [ ] افزودن بررسی در `updateMarketer` برای جلوگیری از تغییر نقش ادمین اصلی
- [ ] افزودن بررسی در `updateMarketer` برای جلوگیری از غیرفعال کردن ادمین اصلی
- [ ] نمایش پیام مناسب به کاربر در صورت تلاش برای تغییر غیرمجاز

## 🔧 رفع مشکلات ماژول پیش‌فاکتورها (اولویت فوری)

### مشکل 1: بسته نشدن تقویم شمسی بعد از انتخاب روز
- [x] بررسی `components/visits/persian-date-time-picker.tsx` ✅
- [x] افزودن `e.preventDefault()` و `e.stopPropagation()` به `handleDateSelect` ✅
- [x] تست بسته شدن تقویم بعد از انتخاب روز ✅

### مشکل 2: نمایش "مشتری ناشناس" در لیست پیش‌فاکتورها
- [x] بررسی `lib/services/invoices.service.ts` در تابع `listInvoices` ✅
- [x] تبدیل `customerId` و `marketerId` از ObjectId به string برای lookup ✅
- [x] بهبود منطق تبدیل `customerId` در map کردن invoices ✅
- [x] **بهبود lookup مشتری با تلاش چندگانه (ObjectId و string)** ✅
- [x] **افزودن console.warn برای دیباگ در صورت عدم یافتن مشتری** ✅
- [x] **بهبود mapping با تلاش چندگانه برای match کردن customerId** ✅
- [x] تست نمایش نام مشتری در لیست پیش‌فاکتورها ✅

### مشکل 3: مشکل دانلود PDF پیش‌فاکتور
- [x] بررسی `components/invoices/invoice-list.tsx` در تابع `handleDownloadPDF` ✅
- [x] بررسی endpoint `/api/invoices/[invoiceId]/pdf` ✅
- [x] اطمینان از دریافت صحیح token از localStorage ✅
- [x] **بهبود PDF generator برای یافتن مسیر فونت‌ها در production** ✅
- [x] **افزودن لاگ برای دیباگ مسیر فونت‌ها** ✅
- [x] **بهبود error handling در PDF generation** ✅
- [x] **استفاده از فونت‌های استاندارد PDF (Times-Roman, Times-Bold) به عنوان fallback** ✅
- [x] **پیاده‌سازی منطق انتخاب فونت: Helvetica اگر موجود باشد، در غیر این صورت Times** ✅
- [x] **بهبود error handling در route handler برای PDF** ✅
- [x] تست دانلود PDF پیش‌فاکتور ✅

### مشکل 4: مشکل باز کردن صفحه جزئیات پیش‌فاکتور
- [x] ایجاد صفحه `/dashboard/invoices/[invoiceId]/page.tsx` ✅
- [x] ایجاد کامپوننت `InvoiceDetailView` ✅
- [x] اتصال دکمه "باز کردن" به صفحه جزئیات ✅
- [x] تست باز شدن صفحه جزئیات پیش‌فاکتور ✅

### مشکل 5: رفع مشکل PDF دانلود (فونت‌های استاندارد)
- [x] استفاده از فونت‌های استاندارد PDF (Times-Roman, Times-Bold) ✅
- [x] حذف نیاز به فایل‌های فونت خارجی ✅
- [x] بهبود error handling در PDF generation ✅
- [x] تست دانلود PDF در production ✅

### مشکل 6: بهبود صفحه SMS Center
- [x] تبدیل به Client Component ✅
- [x] افزودن Toast notification برای دکمه "ایجاد کمپین جدید" ✅
- [x] بهبود UI و UX ✅

---

## 🎯 مراحل بعدی — اولویت‌بندی شده

### فاز 1: تکمیل ماژول Invoices (اولویت بالا) — 2-3 روز

#### 1.1. تغییر وضعیت پرداخت در صفحه جزئیات
- [ ] افزودن دکمه "تغییر وضعیت" در `InvoiceDetailView`
- [ ] ایجاد Modal برای انتخاب وضعیت جدید
- [ ] اتصال به API `PATCH /api/invoices/[id]/status`
- [ ] به‌روزرسانی خودکار UI پس از تغییر وضعیت
- [ ] Confirmation dialog برای تغییرات مهم

#### 1.2. ویرایش پیش‌فاکتور
- [ ] ایجاد Modal ویرایش پیش‌فاکتور
- [ ] Pre-fill داده‌های موجود
- [ ] امکان افزودن/حذف/ویرایش آیتم‌ها
- [ ] محاسبه خودکار جمع کل
- [ ] Validation و error handling

#### 1.3. حذف پیش‌فاکتور
- [ ] افزودن دکمه حذف در صفحه جزئیات
- [ ] Confirmation dialog
- [ ] اتصال به API `DELETE /api/invoices/[id]`
- [ ] ریدایرکت به لیست پس از حذف

#### 1.4. ایندکس‌های MongoDB
- [ ] ایندکس برای `customerId` در collection `invoices`
- [ ] ایندکس برای `status` در collection `invoices`
- [ ] ایندکس برای `dueAt` در collection `invoices`
- [ ] ایندکس ترکیبی برای جستجوهای پیشرفته

---

### فاز 2: پیاده‌سازی ماژول SMS Center (اولویت متوسط) — 3-4 روز

#### 2.1. Backend — Service و API
- [ ] ایجاد `lib/services/sms-campaigns.service.ts`
  - [ ] `createCampaign()` — ایجاد کمپین جدید
  - [ ] `sendCampaignSms()` — ارسال پیامک به لیست مخاطبین
  - [ ] `listCampaigns()` — لیست کمپین‌ها با فیلتر
  - [ ] `getCampaignById()` — جزئیات کمپین
  - [ ] `updateCampaignStatus()` — تغییر وضعیت کمپین
- [ ] ایجاد API Endpoints
  - [ ] `GET /api/sms/campaigns` — لیست کمپین‌ها
  - [ ] `POST /api/sms/campaigns` — ایجاد کمپین
  - [ ] `GET /api/sms/campaigns/[id]` — جزئیات کمپین
  - [ ] `PATCH /api/sms/campaigns/[id]` — ویرایش کمپین
  - [ ] `DELETE /api/sms/campaigns/[id]` — حذف کمپین
  - [ ] `POST /api/sms/campaigns/[id]/send` — ارسال کمپین
  - [ ] `GET /api/sms/logs` — لاگ ارسال‌ها
- [ ] اتصال به سرویس تابان SMS
  - [ ] استفاده از `sendSms` موجود در `lib/vendors/taban-sms.ts`
  - [ ] ارسال به لیست مخاطبین (batch sending)
  - [ ] مدیریت Rate Limiting
  - [ ] ثبت لاگ در `SMSLog` collection

#### 2.2. Frontend — UI کامل
- [ ] ایجاد `SmsCampaignCreateModal` component
  - [ ] انتخاب مخاطبین (مشتریان، بازاریاب‌ها، یا لیست دستی)
  - [ ] نوشتن متن پیام با پیش‌نمایش
  - [ ] زمان‌بندی ارسال (فوری یا زمان‌بندی شده)
  - [ ] Validation و error handling
- [ ] اتصال UI به API
  - [ ] لیست کمپین‌ها از API
  - [ ] آمار ارسال‌ها از API
  - [ ] وضعیت تحویل از API
- [ ] بهبود صفحه SMS Center
  - [ ] نمایش لیست کمپین‌ها با فیلتر
  - [ ] نمایش آمار واقعی از API
  - [ ] دکمه‌های عملیات (ویرایش، حذف، ارسال مجدد)

---

### فاز 3: تکمیل ماژول Reports (اولویت متوسط) — 2-3 روز

#### 3.1. Backend — Service و API
- [ ] ایجاد `lib/services/reports.service.ts`
  - [ ] `getCustomerReports()` — گزارش مشتریان
  - [ ] `getInvoiceReports()` — گزارش پیش‌فاکتورها
  - [ ] `getVisitReports()` — گزارش ویزیت‌ها
  - [ ] `getMarketerPerformance()` — عملکرد بازاریاب‌ها
  - [ ] `exportToExcel()` — خروجی Excel
- [ ] ایجاد API Endpoints
  - [ ] `GET /api/reports/customers` — گزارش مشتریان
  - [ ] `GET /api/reports/invoices` — گزارش پیش‌فاکتورها
  - [ ] `GET /api/reports/visits` — گزارش ویزیت‌ها
  - [ ] `GET /api/reports/marketers` — عملکرد بازاریاب‌ها
  - [ ] `GET /api/reports/export` — خروجی Excel

#### 3.2. Frontend — نمودارها و جداول
- [ ] اتصال به API Reports
- [ ] نمایش نمودارهای تحلیلی (Chart.js یا Recharts)
- [ ] جداول گزارش با فیلترهای پیشرفته
- [ ] دکمه Export به Excel

---

### فاز 4: Import/Export Excel (اولویت متوسط) — 2-3 روز

#### 4.1. Import از Excel — Customers
- [ ] نصب کتابخانه (xlsx یا exceljs)
- [ ] ایجاد API `POST /api/customers/import`
- [ ] Parser برای فایل Excel
- [ ] Validation و error handling
- [ ] نمایش پیش‌نمایش داده قبل از import
- [ ] UI برای آپلود فایل در صفحه Customers

#### 4.2. Export به Excel — Customers
- [ ] ایجاد API `GET /api/customers/export`
- [ ] Generator برای Excel
- [ ] دکمه Export در صفحه Customers
- [ ] دانلود فایل Excel

---

### فاز 5: بهینه‌سازی و بهبود عملکرد (اولویت متوسط) — 2-3 روز

#### 5.1. ایندکس‌های MongoDB
- [ ] ایندکس برای `contact.phone` در collection `customers`
- [ ] ایندکس برای `displayName` در collection `customers`
- [ ] ایندکس برای `status` و `assignedMarketerId` در collection `customers`
- [ ] ایندکس برای `customerId` در collection `visits`
- [ ] ایندکس برای `marketerId` در collection `visits`
- [ ] ایندکس برای `scheduledAt` در collection `visits`
- [ ] ایندکس برای `status` در collection `visits`

#### 5.2. بهینه‌سازی Query‌ها
- [ ] بررسی query‌های کند با `explain()`
- [ ] بهینه‌سازی aggregation pipeline
- [ ] استفاده از projection برای کاهش داده‌های برگشتی
- [ ] Caching برای داده‌های ثابت

#### 5.3. بهینه‌سازی Frontend
- [ ] استفاده از React Query یا SWR برای caching
- [ ] Lazy loading برای صفحات
- [ ] Code splitting
- [ ] بهینه‌سازی bundle size

---

### فاز 6: تست‌های جامع (اولویت بالا) — 3-4 روز

#### 6.1. Unit Tests
- [ ] راه‌اندازی Vitest یا Jest
- [ ] تست Services (customers, visits, invoices, marketers)
- [ ] تست Utilities (jwt, phone, otp)
- [ ] Coverage هدف: 70-80% برای Services

#### 6.2. Integration Tests
- [ ] راه‌اندازی Supertest
- [ ] تست API Endpoints (Auth, Customers, Visits, Invoices, Marketers)
- [ ] تست Database Operations
- [ ] Coverage هدف: 80%+ برای API Endpoints

#### 6.3. E2E Tests
- [ ] راه‌اندازی Playwright یا Cypress
- [ ] سناریو ورود کامل
- [ ] سناریو ایجاد/ویرایش/حذف مشتری
- [ ] سناریو ثبت ویزیت
- [ ] سناریو ایجاد و دانلود PDF پیش‌فاکتور

#### 6.4. Manual Testing
- [ ] تست در Chrome, Firefox, Safari (Desktop)
- [ ] تست در Chrome Mobile, Safari Mobile
- [ ] تست RTL در همه مرورگرها
- [ ] تست Accessibility

---

### فاز 7: آماده‌سازی برای Flutter/Android (اولویت بالا) — 2-3 روز

#### 7.1. Postman Collection کامل
- [ ] به‌روزرسانی Collection برای تمام endpoints
- [ ] افزودن Test Scripts
- [ ] ایجاد Environment برای Production و Development
- [ ] مستندسازی API در Postman

#### 7.2. API Documentation
- [ ] ایجاد `docs/api-documentation.md`
- [ ] مستندسازی تمام endpoints
- [ ] مثال‌های Request/Response
- [ ] کدهای خطا و معنی آن‌ها

#### 7.3. CORS Configuration
- [ ] تنظیم CORS برای Flutter WebView
- [ ] Whitelist دامنه‌های مجاز
- [ ] تست از Flutter WebView

---

### فاز 8: استقرار و تحویل (اولویت بالا) — 1-2 روز

#### 8.1. Build و Deploy
- [ ] ساخت Build نهایی (`next build`)
- [ ] تست Build در محیط local
- [ ] استقرار روی سی‌پنل
- [ ] تست در محیط Production

#### 8.2. SSL و Domain
- [ ] تنظیم SSL روی دامنه
- [ ] اتصال دامنه به برنامه Node.js
- [ ] تست دسترسی از دامنه

#### 8.3. مستندات نهایی
- [ ] به‌روزرسانی README
- [ ] ایجاد راهنمای کاربری
- [ ] تحویل Postman Collection به تیم Flutter

---

## 📊 خلاصه مراحل بعدی

| فاز | مدت زمان | اولویت | وضعیت |
|-----|----------|--------|-------|
| فاز 1: تکمیل Invoices | 2-3 روز | بالا | ⏳ در انتظار |
| فاز 2: SMS Center | 3-4 روز | متوسط | ⏳ در انتظار |
| فاز 3: Reports | 2-3 روز | متوسط | ⏳ در انتظار |
| فاز 4: Import/Export Excel | 2-3 روز | متوسط | ⏳ در انتظار |
| فاز 5: بهینه‌سازی | 2-3 روز | متوسط | ⏳ در انتظار |
| فاز 6: تست‌های جامع | 3-4 روز | بالا | ⏳ در انتظار |
| فاز 7: آماده‌سازی Flutter | 2-3 روز | بالا | ⏳ در انتظار |
| فاز 8: استقرار | 1-2 روز | بالا | ⏳ در انتظار |
| **فاز 9: PWA** | **2-3 روز** | **بالا** | ⏳ در انتظار |
| **فاز 10: تکمیل RBAC** | **3-4 روز** | **بالا** | ⏳ در انتظار |
| **جمع کل** | **22-32 روز** | - | - |

> **توصیه اولویت‌بندی شده**:
> 1. **فاز 10 (تکمیل RBAC)** — اولویت فوری برای امنیت (3-4 روز)
> 2. **فاز 9 (PWA)** — برای تبدیل به اپ موبایل (2-3 روز)
> 3. **فاز 1 (تکمیل Invoices)** — تکمیل ماژول اصلی (2-3 روز)
> 4. **فاز 6 (تست‌ها)** — اطمینان از کیفیت (3-4 روز)
> 5. **فاز 7 (آماده‌سازی Flutter)** — برای انتقال به Native (2-3 روز)
> 6. **فاز 8 (استقرار)** — تحویل نهایی (1-2 روز)

---

## 📱 فاز 9: پیاده‌سازی PWA (Progressive Web App) — اولویت بالا — 2-3 روز

### 9.1. ایجاد Manifest.json
- [ ] ایجاد فایل `public/manifest.json`
- [ ] تنظیم نام، توضیحات، رنگ تم
- [ ] تعریف حالت نمایش (standalone)
- [ ] تعریف شروع URL
- [ ] اتصال manifest به `app/layout.tsx`

### 9.2. ایجاد آیکون‌های PWA
- [ ] ایجاد آیکون 192x192 پیکسل
- [ ] ایجاد آیکون 512x512 پیکسل
- [ ] قرار دادن در `public/icons/`
- [ ] تعریف در manifest.json

### 9.3. پیاده‌سازی Service Worker
- [ ] ایجاد فایل `public/sw.js` یا `public/service-worker.js`
- [ ] Cache کردن فایل‌های استاتیک (CSS, JS, Images)
- [ ] Cache کردن API responses (اختیاری)
- [ ] Offline support (صفحه Offline)
- [ ] Background sync (اختیاری)
- [ ] ثبت Service Worker در `app/layout.tsx`

### 9.4. تست PWA
- [ ] تست نصب روی Android Chrome
- [ ] تست نصب روی iOS Safari
- [ ] تست Offline mode
- [ ] تست به‌روزرسانی خودکار
- [ ] تست عملکرد در حالت Standalone

---

## 🔐 فاز 10: تکمیل RBAC (Role-Based Access Control) — اولویت بالا — 3-4 روز

### 10.1. محدودسازی دسترسی ادمین اصلی ✅
- [x] بررسی نقش `SUPER_ADMIN` در `lib/middleware/rbac.ts` ✅
- [x] جلوگیری از تغییر نقش خود ادمین اصلی ✅
- [x] جلوگیری از غیرفعال کردن حساب خود ادمین اصلی ✅
- [x] افزودن بررسی در `updateMarketer` برای جلوگیری از تغییر نقش ادمین اصلی ✅
- [x] افزودن بررسی در `updateMarketer` برای جلوگیری از غیرفعال کردن ادمین اصلی ✅
- [x] نمایش پیام مناسب به کاربر در صورت تلاش برای تغییر غیرمجاز ✅
- [x] ایجاد `lib/utils/server-auth.ts` برای دریافت userId از token ✅
- [x] به‌روزرسانی `updateMarketerAction` برای دریافت userId فعلی ✅
- [x] افزودن hidden input برای token در `MarketerEditModal` ✅

### 10.2. اعمال RBAC در Frontend (UI) ✅
- [x] ایجاد Hook `usePermissions()` در `lib/hooks/use-permissions.ts` ✅
- [x] ایجاد کامپوننت `ProtectedComponent` در `components/common/protected-component.tsx` ✅
- [x] جداسازی `ROLE_PERMISSIONS` در `lib/permissions/role-permissions.ts` برای استفاده در Client Components ✅
- [x] مخفی کردن دکمه‌ها بر اساس نقش:
  - [x] دکمه "افزودن مشتری" فقط برای MARKETER و SUPER_ADMIN ✅
  - [x] دکمه "افزودن بازاریاب" فقط برای SUPER_ADMIN ✅
  - [x] تب "تنظیمات" فقط برای SUPER_ADMIN ✅
  - [x] دکمه "حذف" مشتری فقط برای SUPER_ADMIN ✅
  - [x] دکمه "حذف" بازاریاب فقط برای SUPER_ADMIN ✅
- [x] مخفی کردن منوی Sidebar بر اساس نقش ✅
- [x] نمایش پیام "دسترسی ندارید" در صورت تلاش برای دسترسی غیرمجاز ✅

### 10.3. اعمال RBAC در API Routes (تکمیل) ✅
- [x] بررسی تمام API Routes و افزودن `requireRole()` یا `requirePermission()` ✅
- [x] محافظت از `/api/customers` (GET: `customers:read`, POST: `customers:write`, PATCH: `customers:write`, DELETE: `customers:delete`) ✅
- [x] محافظت از `/api/marketers` (GET: `marketers:read`, POST: `SUPER_ADMIN`, PATCH: `marketers:write`, DELETE: `SUPER_ADMIN`) ✅
- [x] محافظت از `/api/invoices` (GET: `invoices:read`, POST: `invoices:write`, PATCH: `invoices:write`, DELETE: `invoices:delete`, PDF: `invoices:read`, Status: `invoices:write`) ✅
- [x] محافظت از `/api/visits` (GET: `visits:read`, POST: `visits:write`, PATCH: `visits:write`, DELETE: `visits:delete`, Status: `visits:write`) ✅
- [ ] محافظت از `/api/settings` با `requireRole("SUPER_ADMIN")` (در صورت وجود)
- [ ] محافظت از `/api/reports` با `requirePermission("reports:read")` (در صورت وجود)

### 10.4. صفحه مدیریت نقش‌ها
- [ ] ایجاد صفحه `/dashboard/settings/roles`
- [ ] نمایش لیست نقش‌ها و permissions
- [ ] امکان ایجاد نقش جدید (فقط SUPER_ADMIN)
- [ ] امکان ویرایش permissions نقش‌ها (فقط SUPER_ADMIN)
- [ ] نمایش کاربران هر نقش

---

## 📊 به‌روزرسانی خلاصه مراحل بعدی

| فاز | مدت زمان | اولویت | وضعیت |
|-----|----------|--------|-------|
| فاز 1: تکمیل Invoices | 2-3 روز | بالا | ⏳ در انتظار |
| **فاز 9: PWA** | **2-3 روز** | **بالا** | ⏳ در انتظار |
| **فاز 10: تکمیل RBAC** | **3-4 روز** | **بالا** | ⏳ در انتظار |
| فاز 2: SMS Center | 3-4 روز | متوسط | ⏳ در انتظار |
| فاز 3: Reports | 2-3 روز | متوسط | ⏳ در انتظار |
| فاز 4: Import/Export Excel | 2-3 روز | متوسط | ⏳ در انتظار |
| فاز 5: بهینه‌سازی | 2-3 روز | متوسط | ⏳ در انتظار |
| فاز 6: تست‌های جامع | 3-4 روز | بالا | ⏳ در انتظار |
| فاز 7: آماده‌سازی Flutter | 2-3 روز | بالا | ⏳ در انتظار |
| فاز 8: استقرار | 1-2 روز | بالا | ⏳ در انتظار |
| **جمع کل** | **22-32 روز** | - | - |

> **توصیه به‌روز شده**: 
> 1. **فاز 10 (تکمیل RBAC)** — اولویت فوری برای امنیت
> 2. **فاز 9 (PWA)** — برای تبدیل به اپ موبایل
> 3. **فاز 1 (تکمیل Invoices)** — برای MVP
> 4. **فاز 6 (تست‌ها)** — برای کیفیت
> 5. **فاز 7 (آماده‌سازی Flutter)** — برای انتقال


