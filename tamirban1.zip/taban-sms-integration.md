# راهنمای اتصال OTP به تابان اس‌ام‌اس (IPPanel Edge API)

این سند مسیر تکمیل احراز هویت با پیامک را طبق ساختار فعلی پروژه `tamirban1` (Next.js + MongoDB) مشخص می‌کند. هدف این است که ارسال و تأیید کد یک‌بارمصرف (OTP) به جای حالت تست ثابت `0000`، از طریق سرویس تابان اس‌ام‌اس (IPPanel Edge API) انجام شود.

## 📚 مستندات مرجع

- **آدرس مستندات:** https://ippanelcom.github.io/Edge-Document/docs/
- **Base URL API:** `https://edge.ippanel.com/v1`
- **روش احراز هویت:** API Key در هدر `Authorization`
- **کلید API موجود:** ✅ (در `.env.example` تنظیم شده)

## 1. وضعیت فعلی پروژه

✅ **انجام شده:**
- مسیر درخواست OTP در `app/api/auth/otp/request/route.ts` پیاده‌سازی شده
- سرویس OTP در `lib/services/otp.service.ts` با کد ثابت `0000` کار می‌کند
- هش OTP با `bcrypt` و مدیریت محدودیت تلاش‌ها در دیتابیس انجام می‌شود
- ساختار `SMSLog` در دیتابیس برای ثبت لاگ ارسال‌ها آماده است
- متغیرهای محیطی در `.env.example` تنظیم شده‌اند

⏳ **باقی‌مانده:**
- ایجاد کلاینت تابان اس‌ام‌اس برای ارسال واقعی SMS
- اتصال سرویس OTP به کلاینت تابان
- تست ارسال واقعی و مدیریت خطاها

## 2. اطلاعات مورد نیاز از پنل تابان

برای تکمیل پیاده‌سازی، لطفاً اطلاعات زیر را از پنل کاربری تابان اس‌ام‌اس دریافت کنید:

### ✅ اطلاعات موجود
- ✅ **API Key:** `YTA1Njg1ZjQtOTQ5ZC00MjJmLWI4NWUtOTUwMjQ3MTU1MTA5YzkwZTk1YmRiNGNmMmVlZDkwNzMyMjgzN2I5NDgyNjU=`
- ✅ **Base URL:** `https://edge.ippanel.com/v1`

### ⏳ اطلاعات مورد نیاز
1. **شماره خط خدماتی (Sender Number)**
   - شماره خط مجاز برای ارسال OTP
   - از بخش Numbers در پنل قابل مشاهده است
   - باید در متغیر `TABAN_SMS_SENDER_NUMBER` قرار گیرد

2. **Endpoint ارسال SMS**
   - مسیر دقیق API برای ارسال پیامک (مثلاً `/sms/send` یا `/messages/send`)
   - بررسی مستندات بخش "Send SMS" در https://ippanelcom.github.io/Edge-Document/docs/send
   - ساختار درخواست (Body parameters: recipient, message, sender)

3. **محدودیت‌ها و قوانین**
   - Rate Limit (تعداد درخواست مجاز در دقیقه/ساعت)
   - محدودیت طول پیام (تعداد کاراکتر)
   - محدودیت ساعت ارسال (در صورت وجود)
   - کدهای خطا و معنی آن‌ها

4. **الگوی پیامک (Pattern) - ✅ فعال شده**
   - ✅ **Pattern Code:** `0wopnv45vvw7mss` (در `.env.example` تنظیم شده)
   - ⚠️ **ساختار متغیرهای الگو:** باید از پنل تابان بررسی شود (احتمالاً `{code}` یا `{otp}`)
   - ✅ **پیاده‌سازی:** کلاینت تابان برای استفاده از Pattern به‌روزرسانی شده است

## 3. تغییرات فنی مورد نیاز

### 3.1. ایجاد کلاینت تابان اس‌ام‌اس

**فایل جدید:** `lib/vendors/taban-sms.ts`

```typescript
// ساختار پیشنهادی
export interface TabaanSmsConfig {
  baseUrl: string;
  apiKey: string;
  senderNumber: string;
}

export interface SendSmsParams {
  phone: string; // شماره گیرنده (با فرمت 09123456789)
  message: string; // متن پیامک
}

export interface TabaanSmsResponse {
  success: boolean;
  messageId?: string;
  error?: string;
}

export async function sendSms(params: SendSmsParams): Promise<TabaanSmsResponse> {
  // پیاده‌سازی با fetch
  // استفاده از API Key در هدر Authorization
  // مدیریت خطاها و retry
}
```

### 3.2. به‌روزرسانی سرویس OTP

**فایل:** `lib/services/otp.service.ts`

تغییرات:
- پس از تولید کد OTP، فراخوانی `sendSms` به جای بازگرداندن کد
- در صورت موفقیت ارسال، ثبت لاگ در `SMSLog` با وضعیت `QUEUED`
- در صورت خطا، ثبت لاگ با وضعیت `FAILED` و throw کردن خطا
- در محیط Production، حذف بازگرداندن کد از پاسخ API

### 3.2.1. پشتیبانی از Pattern SMS ✅

**فایل:** `lib/vendors/taban-sms.ts`

**تغییرات انجام شده:**
- ✅ افزودن متغیر محیطی `TABAN_SMS_PATTERN_CODE=0wopnv45vvw7mss` به `.env.example`
- ✅ به‌روزرسانی `SendSmsParams` برای پشتیبانی از `patternCode` و `patternValues`
- ✅ به‌روزرسانی تابع `sendSms` برای پشتیبانی از Pattern API:
  - اگر `patternCode` و `patternValues` موجود باشند، از Pattern API استفاده می‌شود
  - در غیر این صورت، از روش قدیمی (متن مستقیم) استفاده می‌شود
- ✅ به‌روزرسانی تابع `sendOtpSms`:
  - خواندن `TABAN_SMS_PATTERN_CODE` از متغیرهای محیطی
  - استفاده از Pattern اگر موجود باشد
  - Fallback به روش قدیمی اگر Pattern موجود نباشد

**ساختار Pattern API:**
```typescript
{
  sending_type: "webservice",
  from_number: "3000505",
  pattern_code: "0wopnv45vvw7mss",
  pattern_values: {
    code: "1234" // نام متغیر باید از پنل تابان بررسی شود (ممکن است "otp" باشد)
  },
  params: {
    recipients: ["09123456789"]
  }
}
```

**نکته مهم:** نام متغیر Pattern (مثلاً `code` یا `otp`) باید از پنل تابان بررسی شود. در حال حاضر از `code` استفاده شده است.

### 3.3. ثبت لاگ ارسال

**استفاده از:** `lib/repositories/sms-logs.repository.ts`

پس از هر درخواست ارسال:
- ایجاد رکورد `SMSLog` با:
  - `recipient`: شماره گیرنده
  - `message`: متن پیام (بدون نمایش کد OTP در لاگ)
  - `status`: `QUEUED` → بعداً با webhook یا polling به `DELIVERED`/`FAILED` تبدیل شود
  - `provider`: `"TABAN_SMS"`
  - `providerMessageId`: شناسه پیام از پاسخ API تابان

### 3.4. مدیریت خطاها

خطاهای احتمالی:
- **شبکه:** Timeout، عدم دسترسی به API
- **احراز هویت:** API Key نامعتبر یا منقضی شده
- **اعتبار:** موجودی ناکافی در حساب تابان
- **اعتبارسنجی:** شماره گیرنده نامعتبر، متن خالی
- **Rate Limit:** تعداد درخواست بیش از حد

برای هر خطا:
- ثبت در `SMSLog` با وضعیت `FAILED`
- بازگرداندن پیام خطای مناسب به کاربر (بدون افشای جزئیات فنی)
- Log کردن جزئیات خطا در console برای دیباگ

## 4. چک‌لیست پیاده‌سازی

مراحل کار در `todo.md` (فاز 5) به‌صورت زیر مشخص شده:

- [ ] افزودن متغیرهای محیطی تابان اس‌ام‌اس به `.env.example` ✅ (انجام شد)
- [ ] ایجاد کلاینت تابان اس‌ام‌اس در `lib/vendors/taban-sms.ts`
- [ ] بررسی مستندات API تابان برای endpoint ارسال SMS
- [ ] پیاده‌سازی `sendOtpSms(phone, code)` با API Key
- [ ] به‌روزرسانی `lib/services/otp.service.ts` برای فراخوانی سرویس واقعی
- [ ] مدیریت خطاهای ارسال SMS و پیام‌های مناسب
- [ ] ثبت لاگ ارسال در کالکشن `SMSLog`
- [ ] تست ارسال واقعی با شماره موبایل
- [ ] حذف بازگرداندن کد OTP از پاسخ API در Production

## 5. تست و اعتبارسنجی

### 5.1. تست واحد
- Mock کردن کلاینت تابان برای تست سرویس OTP
- تست سناریوهای موفق/ناموفق ارسال

### 5.2. تست یکپارچگی
- درخواست OTP از طریق Postman یا UI
- بررسی دریافت پیامک روی شماره واقعی
- بررسی ثبت لاگ در دیتابیس
- تست تأیید کد و ورود موفق

### 5.3. تست خطا
- تست با API Key نامعتبر
- تست با شماره نامعتبر
- تست با موجودی ناکافی (در صورت امکان)

## 6. مستندات تکمیلی

پس از تکمیل پیاده‌سازی:
- به‌روزرسانی `docs/authentication-plan.md` با جزئیات تابان
- افزودن مثال‌های Postman برای تست API
- مستندسازی کدهای خطا و راه‌حل‌های رایج

---

**نکته مهم:** 
- قبل از استقرار در Production، حتماً `TABAN_SMS_SENDER_NUMBER` را از پنل تابان دریافت و در `.env` سرور تنظیم کنید.
- ✅ `TABAN_SMS_PATTERN_CODE` تنظیم شده است: `0wopnv45vvw7mss`
- ⚠️ **نیاز به بررسی:** نام متغیر Pattern (مثلاً `code` یا `otp`) باید از پنل تابان بررسی شود و در صورت نیاز در کد به‌روزرسانی شود.
