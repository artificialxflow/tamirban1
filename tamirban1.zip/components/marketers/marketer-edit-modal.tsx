"use client";

import { useEffect, useRef, useActionState } from "react";
import { useFormStatus } from "react-dom";

import { updateMarketerAction, type UpdateMarketerFormState } from "@/app/dashboard/marketers/actions";
import type { MarketerSummary } from "@/lib/services/marketers.service";

const updateMarketerDefaultState: UpdateMarketerFormState = {
  success: false,
  message: null,
};

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      className="rounded-2xl bg-gradient-primary px-5 py-3 text-sm font-semibold text-white shadow-soft-primary transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-70"
      disabled={pending}
    >
      {pending ? "در حال به‌روزرسانی..." : "به‌روزرسانی بازاریاب"}
    </button>
  );
}

interface MarketerEditModalProps {
  marketer: MarketerSummary;
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export function MarketerEditModal({ marketer, isOpen, onClose, onSuccess }: MarketerEditModalProps) {
  const formRef = useRef<HTMLFormElement>(null);
  const [state, formAction] = useActionState(updateMarketerAction, updateMarketerDefaultState);

  useEffect(() => {
    if (state.success) {
      onSuccess?.();
      setTimeout(() => {
        onClose();
      }, 1000);
    }
  }, [state.success, onClose, onSuccess]);

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl rounded-3xl border border-slate-200/60 bg-white/95 backdrop-blur-sm p-6 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute left-6 top-6 rounded-full p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
          aria-label="بستن"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <header className="mb-6 border-b border-slate-100 pb-4">
          <h2 className="text-xl font-semibold text-slate-800">ویرایش بازاریاب</h2>
          <p className="mt-1 text-sm text-slate-500">اطلاعات بازاریاب را ویرایش کنید</p>
        </header>

        {state.message ? (
          <div
            className={`mb-4 rounded-2xl border px-4 py-3 text-sm font-medium ${
              state.success
                ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                : "border-rose-200 bg-rose-50 text-rose-600"
            }`}
          >
            {state.message}
          </div>
        ) : null}

        <form ref={formRef} className="grid grid-cols-1 gap-4 md:grid-cols-2" action={formAction}>
          <input type="hidden" name="marketerId" value={marketer.id} />

          <label className="flex flex-col gap-2 text-sm font-medium text-slate-700">
            نام و نام خانوادگی
            <input
              name="fullName"
              required
              defaultValue={marketer.fullName}
              placeholder="مثال: سارا احمدی"
              className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-primary-400 focus:ring-2 focus:ring-primary-100"
            />
          </label>

          <label className="flex flex-col gap-2 text-sm font-medium text-slate-700">
            شماره موبایل
            <input
              name="mobile"
              type="tel"
              required
              defaultValue={marketer.mobile}
              placeholder="09123456789"
              className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-primary-400 focus:ring-2 focus:ring-primary-100"
            />
          </label>

          <label className="flex flex-col gap-2 text-sm font-medium text-slate-700">
            ایمیل (اختیاری)
            <input
              name="email"
              type="email"
              defaultValue={marketer.email || ""}
              placeholder="example@domain.com"
              className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-primary-400 focus:ring-2 focus:ring-primary-100"
            />
          </label>

          <label className="flex flex-col gap-2 text-sm font-medium text-slate-700">
            منطقه
            <input
              name="region"
              required
              defaultValue={marketer.region}
              placeholder="مثال: تهران"
              className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-primary-400 focus:ring-2 focus:ring-primary-100"
            />
          </label>

          <label className="md:col-span-2 flex flex-col gap-2 text-sm font-medium text-slate-700">
            نقش
            <select
              name="role"
              defaultValue={marketer.role}
              className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-primary-400 focus:ring-2 focus:ring-primary-100"
            >
              <option value="MARKETER">بازاریاب</option>
              <option value="FINANCE_MANAGER">مدیر مالی</option>
              <option value="SUPER_ADMIN">مدیر کل</option>
            </select>
          </label>

          <label className="md:col-span-2 flex items-center gap-3">
            <input
              name="isActive"
              type="checkbox"
              defaultChecked={marketer.isActive}
              className="h-4 w-4 rounded border-slate-300 text-primary-500 focus:ring-primary-500"
            />
            <span className="text-sm font-medium text-slate-700">حساب کاربری فعال است</span>
          </label>

          <div className="md:col-span-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="rounded-2xl border border-slate-200 px-5 py-3 text-sm font-semibold text-slate-600 transition hover:border-slate-300 hover:text-slate-800"
            >
              انصراف
            </button>
            <SubmitButton />
          </div>
        </form>
      </div>
    </div>
  );
}

