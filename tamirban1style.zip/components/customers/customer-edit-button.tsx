"use client";

import { useState } from "react";

import { CustomerEditModal } from "./customer-edit-modal";
import type { CustomerDetail } from "@/lib/services/customers.service";

interface CustomerEditButtonProps {
  customer: CustomerDetail;
  onSuccess?: () => void;
}

export function CustomerEditButton({ customer, onSuccess }: CustomerEditButtonProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="rounded-full bg-sky-500 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-sky-600"
      >
        ویرایش
      </button>
      <CustomerEditModal
        customer={customer}
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onSuccess={onSuccess}
      />
    </>
  );
}

