"use client";

import { useRouter } from "next/navigation";
import type { InvoiceSummary } from "@/lib/services/invoices.service";

const STATUS_LABELS: Record<string, string> = {
  DRAFT: "پیش‌نویس",
  SENT: "ارسال شده",
  PAID: "پرداخت شد",
  OVERDUE: "معوق",
  CANCELLED: "لغو شد",
};

const STATUS_BADGE_CLASS: Record<string, string> = {
  DRAFT: "bg-slate-100 text-slate-600",
  SENT: "bg-sky-100 text-sky-600",
  PAID: "bg-emerald-100 text-emerald-600",
  OVERDUE: "bg-orange-100 text-orange-600",
  CANCELLED: "bg-rose-100 text-rose-600",
};

const numberFormatter = new Intl.NumberFormat("fa-IR");
const dateFormatter = new Intl.DateTimeFormat("fa-IR", {
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});

function formatDate(value: Date) {
  return dateFormatter.format(value);
}

function formatAmount(value: number) {
  return numberFormatter.format(value);
}

interface InvoiceListProps {
  invoices: InvoiceSummary[];
}

export function InvoiceList({ invoices }: InvoiceListProps) {
  const router = useRouter();

  const handleDownloadPDF = async (invoiceId: string) => {
    const token = document.cookie
      .split("; ")
      .find((row) => row.startsWith("authToken="))
      ?.split("=")[1];

    if (!token) {
      alert("لطفا دوباره وارد شوید");
      return;
    }

    try {
      const response = await fetch(`/api/invoices/${invoiceId}/pdf`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error("خطا در دانلود PDF");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `invoice-${invoiceId}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      alert("خطا در دانلود PDF: " + (error instanceof Error ? error.message : "خطای ناشناخته"));
    }
  };

  return (
    <tbody className="divide-y divide-slate-100 bg-white">
      {invoices.length === 0 ? (
        <tr>
          <td colSpan={8} className="px-6 py-12 text-center text-sm text-slate-500">
            هیچ پیش‌فاکتوری یافت نشد
          </td>
        </tr>
      ) : (
        invoices.map((invoice) => (
          <tr key={invoice.id} className="transition hover:bg-slate-50">
            <td className="px-6 py-4 text-xs text-slate-400">{invoice.invoiceNumber}</td>
                    <td className="px-6 py-4 font-semibold text-slate-800">{invoice.customerName}</td>
            <td className="px-6 py-4 text-sm text-slate-600">{invoice.marketerName || "-"}</td>
            <td className="px-6 py-4 text-xs font-semibold text-slate-800">
              {formatAmount(invoice.grandTotal)} {invoice.currency === "IRR" ? "ریال" : "دلار"}
            </td>
            <td className="px-6 py-4">
              <span
                className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${
                  STATUS_BADGE_CLASS[invoice.status] || STATUS_BADGE_CLASS.DRAFT
                }`}
              >
                {STATUS_LABELS[invoice.status] || invoice.status}
              </span>
            </td>
            <td className="px-6 py-4 text-xs text-slate-500">{formatDate(invoice.issuedAt)}</td>
            <td className="px-6 py-4 text-xs text-slate-500">{formatDate(invoice.dueAt)}</td>
            <td className="px-6 py-4">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleDownloadPDF(invoice.id)}
                  className="rounded-full border border-slate-200 px-3 py-1 text-xs text-slate-600 transition hover:border-slate-300 hover:text-slate-800"
                >
                  PDF
                </button>
                <button
                  onClick={() => router.push(`/dashboard/invoices/${invoice.id}`)}
                  className="rounded-full border border-slate-200 px-3 py-1 text-xs text-slate-600 transition hover:border-slate-300 hover:text-slate-800"
                >
                  باز کردن
                </button>
              </div>
            </td>
          </tr>
        ))
      )}
    </tbody>
  );
}

